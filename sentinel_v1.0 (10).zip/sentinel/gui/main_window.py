"""
gui/main_window.py
==================
Root application window.

Layout
------
  Left sidebar (navigation) | Right content area (stacked pages)

Pages
-----
  - Dashboard  (real-time feed + counters)
  - Scan Feed  (scrolling scan events)
  - History    (searchable table of all past scans)
  - Settings   (API key, watch path, etc.)
"""

from __future__ import annotations

import logging
from pathlib import Path

from PySide6.QtCore import Qt, QSize, QTimer, Slot
from PySide6.QtGui import QIcon, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QSizePolicy,
    QStatusBar,
    QVBoxLayout,
    QWidget,
    QStackedWidget,
    QPushButton,
    QFrame,
    QSpacerItem,
    QMessageBox,
)

from core.config import Config
from core.models import ScanResult, ScanStatus, ThreatLevel
from database.db_manager import DatabaseManager
from scanner.folder_watcher import FolderWatcher
from scanner.scan_queue import ScanQueue, ScanQueueSignals
from gui.styles import COLORS
from gui.pages.dashboard import DashboardPage
from gui.pages.scan_feed import ScanFeedPage
from gui.pages.history import HistoryPage
from gui.pages.settings import SettingsPage
from gui.pages.file_detail import FileDetailPage
from gui.pages.about import AboutPage

log = logging.getLogger("sentinel.gui.main_window")


class MainWindow(QMainWindow):
    """
    Top-level application window.

    Parameters
    ----------
    config : Config
        Application configuration.
    db : DatabaseManager
        Shared database manager.
    """

    def __init__(self, config: Config, db: DatabaseManager) -> None:
        super().__init__()
        self._config = config
        self._db = db

        # Qt signals — must outlive the scan queue
        self._signals = ScanQueueSignals(self)

        # Scan pipeline
        self._scan_queue = ScanQueue(
            config=config,
            db=db,
            signals=self._signals,
            num_workers=2,
        )
        self._watcher = FolderWatcher(
            watch_path=config.watch_path,
            on_new_file=self._scan_queue.enqueue,
            ignored_extensions=config.ignored_extensions,
        )

        self._setup_ui()
        self._connect_signals()
        self._setup_menu()
        self._start_services()

        # Status bar update timer
        self._status_timer = QTimer(self)
        self._status_timer.timeout.connect(self._update_status_bar)
        self._status_timer.start(5000)

    # ------------------------------------------------------------------ #
    #  UI Construction                                                     #
    # ------------------------------------------------------------------ #

    def _setup_ui(self) -> None:
        self.setWindowTitle("Sentinel Security Monitor")
        self.setMinimumSize(1100, 700)
        self.resize(1280, 800)

        # Central widget container
        central = QWidget()
        self.setCentralWidget(central)

        main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # ── Sidebar ──
        self._sidebar = self._build_sidebar()
        main_layout.addWidget(self._sidebar)

        # ── Content stack ──
        self._stack = QStackedWidget()
        main_layout.addWidget(self._stack, stretch=1)

        # ── Pages ──
        self._dashboard_page = DashboardPage(config=self._config, db=self._db)
        self._feed_page       = ScanFeedPage()
        self._history_page    = HistoryPage(db=self._db)
        self._settings_page   = SettingsPage(config=self._config)
        self._detail_page     = FileDetailPage()
        self._about_page      = AboutPage()

        self._stack.addWidget(self._dashboard_page)  # index 0
        self._stack.addWidget(self._feed_page)        # index 1
        self._stack.addWidget(self._history_page)     # index 2
        self._stack.addWidget(self._settings_page)    # index 3
        self._stack.addWidget(self._detail_page)      # index 4
        self._stack.addWidget(self._about_page)       # index 5

        # ── Status bar ──
        self._status_bar = QStatusBar()
        self.setStatusBar(self._status_bar)
        self._status_label = QLabel("Monitoring paused")
        self._queue_label  = QLabel("")
        self._status_bar.addWidget(self._status_label)
        self._status_bar.addPermanentWidget(self._queue_label)

        # Start on dashboard
        self._navigate(0)

    def _build_sidebar(self) -> QWidget:
        """Build the left navigation sidebar."""
        sidebar = QFrame()
        sidebar.setMinimumWidth(200)
        sidebar.setMaximumWidth(260)
        sidebar.setObjectName("sidebar")
        sidebar.setStyleSheet(f"""
            QFrame#sidebar {{
                background-color: {COLORS['bg_deep']};
                border-right: 1px solid {COLORS['border']};
            }}
        """)

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Logo / title ──
        logo_frame = QFrame()
        logo_frame.setFixedHeight(72)
        logo_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['bg_darkest']};
                border-bottom: 1px solid {COLORS['border']};
            }}
        """)
        logo_layout = QVBoxLayout(logo_frame)
        logo_layout.setContentsMargins(16, 0, 16, 0)

        title = QLabel("🛡 SENTINEL")
        title.setStyleSheet(f"""
            font-size: 15px;
            font-weight: 800;
            color: {COLORS['accent_cyan']};
            letter-spacing: 2px;
        """)
        subtitle = QLabel("Security Monitor")
        subtitle.setStyleSheet(f"""
            font-size: 10px;
            color: {COLORS['text_muted']};
            letter-spacing: 1px;
        """)
        logo_layout.addWidget(title)
        logo_layout.addWidget(subtitle)
        layout.addWidget(logo_frame)

        # ── Nav section label ──
        layout.addSpacing(12)
        nav_label = QLabel("NAVIGATION")
        nav_label.setStyleSheet(f"""
            font-size: 10px;
            color: {COLORS['text_muted']};
            letter-spacing: 1.5px;
            padding: 0 16px;
        """)
        layout.addWidget(nav_label)
        layout.addSpacing(4)

        # ── Nav buttons ──
        self._nav_buttons: list[QPushButton] = []

        nav_items = [
            ("Dashboard",   "⬛", 0, "Overview & real-time status"),
            ("Live Feed",   "📡", 1, "Real-time scan events"),
            ("History",     "📋", 2, "All past scan results"),
            ("Settings",    "⚙",  3, "Configuration"),
            ("Über / Update", "ℹ",  5, "Version & Updates"),
        ]

        for label, icon, index, tooltip in nav_items:
            btn = self._make_nav_button(f"  {icon}  {label}", index, tooltip)
            self._nav_buttons.append(btn)
            layout.addWidget(btn)

        layout.addStretch()

        # ── Monitoring status indicator ──
        self._monitor_status = QLabel("● MONITORING ACTIVE")
        self._monitor_status.setStyleSheet(f"""
            font-size: 10px;
            color: {COLORS['success']};
            padding: 12px 16px;
            letter-spacing: 0.5px;
        """)
        layout.addWidget(self._monitor_status)

        # ── Scan folder indicator ──
        watch_label = QLabel(f"📁  {Path(self._config.watch_path).name}")
        watch_label.setStyleSheet(f"""
            font-size: 10px;
            color: {COLORS['text_muted']};
            padding: 4px 16px 16px;
        """)
        watch_label.setWordWrap(True)
        layout.addWidget(watch_label)
        self._watch_label = watch_label

        return sidebar

    def _make_nav_button(self, label: str, page_index: int, tooltip: str) -> QPushButton:
        """Create a styled navigation button."""
        btn = QPushButton(label)
        btn.setToolTip(tooltip)
        btn.setFixedHeight(44)
        btn.setCheckable(True)
        btn.clicked.connect(lambda checked, i=page_index: self._navigate(i))
        btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                color: {COLORS['text_secondary']};
                border: none;
                border-radius: 0;
                text-align: left;
                padding: 0 12px;
                font-size: 12px;
                font-weight: 500;
            }}
            QPushButton:hover {{
                background-color: {COLORS['bg_card']};
                color: {COLORS['text_primary']};
            }}
            QPushButton:checked {{
                background-color: {COLORS['bg_surface']};
                color: {COLORS['accent_cyan']};
                border-left: 3px solid {COLORS['accent']};
                padding-left: 9px;
            }}
        """)
        return btn

    # ------------------------------------------------------------------ #
    #  Menu                                                                #
    # ------------------------------------------------------------------ #

    def _setup_menu(self) -> None:
        mb = self.menuBar()

        # ── File ──
        file_menu = mb.addMenu("&File")
        scan_action = file_menu.addAction("Scan File Manually…")
        scan_action.setShortcut(QKeySequence("Ctrl+O"))
        scan_action.triggered.connect(self._manual_scan)

        export_action = file_menu.addAction("Export Report…")
        export_action.triggered.connect(self._export_report)

        file_menu.addSeparator()
        quit_action = file_menu.addAction("Quit")
        quit_action.setShortcut(QKeySequence("Ctrl+Q"))
        quit_action.triggered.connect(QApplication.quit)

        # ── Monitoring ──
        mon_menu = mb.addMenu("&Monitoring")
        self._action_start = mon_menu.addAction("Start Monitoring")
        self._action_start.triggered.connect(self._start_monitoring)
        self._action_stop = mon_menu.addAction("Stop Monitoring")
        self._action_stop.triggered.connect(self._stop_monitoring)
        mon_menu.addSeparator()
        clear_action = mon_menu.addAction("Clear History…")
        clear_action.triggered.connect(self._clear_history)

        # ── View ──
        view_menu = mb.addMenu("&View")
        view_menu.addAction("Dashboard").triggered.connect(lambda: self._navigate(0))
        view_menu.addAction("Live Feed").triggered.connect(lambda: self._navigate(1))
        view_menu.addAction("History").triggered.connect(lambda: self._navigate(2))

        # ── Help ──
        help_menu = mb.addMenu("&Help")
        help_menu.addAction("About Sentinel").triggered.connect(self._show_about)

    # ------------------------------------------------------------------ #
    #  Signal connections                                                  #
    # ------------------------------------------------------------------ #

    def _connect_signals(self) -> None:
        self._signals.scan_complete.connect(self._on_scan_complete)
        self._signals.scan_started.connect(self._on_scan_started)
        self._signals.job_queued.connect(self._on_job_queued)
        self._signals.stats_updated.connect(self._on_stats_updated)
        self._signals.scan_error.connect(self._on_scan_error)

        # Settings page: watch path changed
        self._settings_page.watch_path_changed.connect(self._on_watch_path_changed)

        # History page: view detail requested
        self._history_page.view_detail_requested.connect(self._show_detail)

        # Detail page: back button
        self._detail_page._back_btn.clicked.connect(lambda: self._navigate(2))

        # Feed page: view detail requested
        self._feed_page.view_detail_requested.connect(self._show_detail)

    # ------------------------------------------------------------------ #
    #  Navigation                                                          #
    # ------------------------------------------------------------------ #

    @Slot(int)
    def _navigate(self, index: int) -> None:
        """Switch to the page at *index*."""
        self._stack.setCurrentIndex(index)
        for i, btn in enumerate(self._nav_buttons):
            btn.setChecked(i == index)

    def _show_detail(self, result: ScanResult) -> None:
        """Open the file detail view for *result*."""
        self._detail_page.load_result(result)
        self._stack.setCurrentIndex(4)
        # Don't mark any nav button as active for detail view

    # ------------------------------------------------------------------ #
    #  Lifecycle                                                           #
    # ------------------------------------------------------------------ #

    def _start_services(self) -> None:
        """Start the scan queue and folder watcher."""
        self._scan_queue.start()
        self._watcher.start()
        self._update_monitor_indicator(running=True)
        self._status_label.setText(
            f"Monitoring: {self._config.watch_path}"
        )
        log.info("Services started.")

    def _start_monitoring(self) -> None:
        if not self._watcher.is_running:
            self._watcher.start()
            self._update_monitor_indicator(True)

    def _stop_monitoring(self) -> None:
        if self._watcher.is_running:
            self._watcher.stop()
            self._update_monitor_indicator(False)

    def _update_monitor_indicator(self, running: bool) -> None:
        if running:
            self._monitor_status.setText("● MONITORING ACTIVE")
            self._monitor_status.setStyleSheet(f"""
                font-size: 10px; color: {COLORS['success']};
                padding: 12px 16px; letter-spacing: 0.5px;
            """)
        else:
            self._monitor_status.setText("○ MONITORING STOPPED")
            self._monitor_status.setStyleSheet(f"""
                font-size: 10px; color: {COLORS['text_muted']};
                padding: 12px 16px; letter-spacing: 0.5px;
            """)

    # ------------------------------------------------------------------ #
    #  Scan signal handlers                                                #
    # ------------------------------------------------------------------ #

    @Slot(str)
    def _on_job_queued(self, filename: str) -> None:
        self._status_label.setText(f"Queued: {filename}")

    @Slot(str)
    def _on_scan_started(self, filename: str) -> None:
        self._status_label.setText(f"Scanning: {filename}")
        self._feed_page.add_scanning_item(filename)

    @Slot(object)
    def _on_scan_complete(self, result: ScanResult) -> None:
        log.info(
            "Scan complete: %s → %s (risk=%d)",
            result.filename,
            result.threat_level,
            result.risk_score,
        )
        self._feed_page.update_item(result)
        self._dashboard_page.refresh()
        self._history_page.prepend_result(result)

        # Show threat notification for suspicious/malicious files
        if result.threat_level in (ThreatLevel.MALICIOUS, ThreatLevel.SUSPICIOUS):
            self._dashboard_page.show_alert(result)

    @Slot(str, str)
    def _on_scan_error(self, filename: str, error: str) -> None:
        self._status_label.setText(f"Error scanning {filename}")
        log.error("Scan error — %s: %s", filename, error)

    @Slot(int, int, int)
    def _on_stats_updated(self, queued: int, processing: int, done: int) -> None:
        self._queue_label.setText(
            f"Queue: {queued}  |  Processing: {processing}  |  Done: {done}"
        )

    # ------------------------------------------------------------------ #
    #  Actions                                                             #
    # ------------------------------------------------------------------ #

    def _manual_scan(self) -> None:
        """Open file picker and enqueue selected files."""
        files, _ = QFileDialog.getOpenFileNames(
            self, "Select Files to Scan", str(Path.home()), "All Files (*.*)"
        )
        if files:
            paths = [Path(f) for f in files]
            count = self._scan_queue.enqueue_bulk(paths)
            self._status_label.setText(f"Enqueued {count} file(s) for scanning.")

    def _export_report(self) -> None:
        """Export scan history as a PDF report."""
        from utils.report_generator import generate_pdf_report
        save_path, _ = QFileDialog.getSaveFileName(
            self, "Save Scan Report", str(self._config.reports_dir / "sentinel_report.pdf"),
            "PDF Files (*.pdf)"
        )
        if save_path:
            try:
                results = self._db.get_recent_scans(limit=200)
                generate_pdf_report(results, Path(save_path))
                QMessageBox.information(self, "Report Saved", f"Report saved to:\n{save_path}")
            except Exception as exc:
                QMessageBox.warning(self, "Export Failed", f"Could not generate report:\n{exc}")

    def _clear_history(self) -> None:
        reply = QMessageBox.question(
            self,
            "Clear History",
            "This will permanently delete all scan history.\nAre you sure?",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply == QMessageBox.Yes:
            self._db.clear_history()
            self._history_page.refresh()
            self._dashboard_page.refresh()

    def _show_about(self) -> None:
        QMessageBox.about(
            self,
            "About Sentinel",
            "<h2>🛡 Sentinel Security Monitor</h2>"
            "<p>Version 1.0.0</p>"
            "<p>A Windows Defender-inspired malware analysis tool "
            "powered by VirusTotal.</p>"
            "<hr>"
            "<p><b>This tool is purely defensive and educational.</b></p>"
            "<p>It never deletes, modifies, or executes files.</p>",
        )

    @Slot(str)
    def _on_watch_path_changed(self, new_path: str) -> None:
        """Restart folder watcher on a new path."""
        self._watcher.stop()
        self._config.watch_path = Path(new_path)
        self._watcher = FolderWatcher(
            watch_path=self._config.watch_path,
            on_new_file=self._scan_queue.enqueue,
            ignored_extensions=self._config.ignored_extensions,
        )
        self._watcher.start()
        self._watch_label.setText(f"📁  {Path(new_path).name}")
        self._status_label.setText(f"Monitoring: {new_path}")

    # ------------------------------------------------------------------ #
    #  Status bar                                                          #
    # ------------------------------------------------------------------ #

    def _update_status_bar(self) -> None:
        if self._watcher.is_running:
            self._update_monitor_indicator(True)

    # ------------------------------------------------------------------ #
    #  Cleanup                                                             #
    # ------------------------------------------------------------------ #

    def closeEvent(self, event) -> None:
        log.info("Shutting down Sentinel…")
        self._watcher.stop()
        self._scan_queue.stop()
        event.accept()
