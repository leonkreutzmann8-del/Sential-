"""
gui/pages/dashboard.py
======================
Main dashboard page — overview of the system status, counters,
recent threats, and real-time threat level indicator.
"""

from __future__ import annotations

import logging
from datetime import datetime

from PySide6.QtCore import Qt, QTimer, Slot
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from core.config import Config
from core.models import ScanResult, ThreatLevel
from database.db_manager import DatabaseManager
from gui.styles import COLORS

log = logging.getLogger("sentinel.gui.dashboard")


class StatCard(QFrame):
    """A single KPI card with a number, label, and optional colour."""

    def __init__(
        self,
        title: str,
        value: str = "0",
        color: str = COLORS["text_primary"],
        icon: str = "",
    ) -> None:
        super().__init__()
        self.setObjectName("stat_card")
        self.setFixedHeight(100)
        self.setStyleSheet(f"""
            QFrame#stat_card {{
                background-color: {COLORS['bg_card']};
                border: 1px solid {COLORS['border']};
                border-radius: 10px;
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(4)

        top = QHBoxLayout()
        if icon:
            icon_lbl = QLabel(icon)
            icon_lbl.setStyleSheet(f"font-size: 20px; color: {color};")
            top.addWidget(icon_lbl)
        top.addStretch()
        layout.addLayout(top)

        self._value_lbl = QLabel(value)
        self._value_lbl.setStyleSheet(f"""
            font-size: 30px;
            font-weight: 800;
            color: {color};
        """)
        layout.addWidget(self._value_lbl)

        title_lbl = QLabel(title.upper())
        title_lbl.setStyleSheet(f"""
            font-size: 10px;
            color: {COLORS['text_muted']};
            letter-spacing: 1px;
        """)
        layout.addWidget(title_lbl)

    def set_value(self, value: str | int) -> None:
        self._value_lbl.setText(str(value))


class ThreatLevelBadge(QFrame):
    """Large visual badge showing the current threat level."""

    _LEVEL_CONFIG = {
        ThreatLevel.CLEAN:      ("#00C853", "✓", "ALL CLEAR"),
        ThreatLevel.SUSPICIOUS: ("#FFD600", "⚠", "SUSPICIOUS"),
        ThreatLevel.MALICIOUS:  ("#E53935", "✕", "THREAT DETECTED"),
        ThreatLevel.UNKNOWN:    ("#8B9CB8", "?", "NO DATA"),
    }

    def __init__(self) -> None:
        super().__init__()
        self.setFixedHeight(140)
        self._level = ThreatLevel.UNKNOWN
        self.setObjectName("threat_badge")

        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(4)

        self._icon_lbl = QLabel("?")
        self._icon_lbl.setAlignment(Qt.AlignCenter)
        self._icon_lbl.setStyleSheet("font-size: 36px;")
        layout.addWidget(self._icon_lbl)

        self._status_lbl = QLabel("NO DATA")
        self._status_lbl.setAlignment(Qt.AlignCenter)
        self._status_lbl.setStyleSheet(f"""
            font-size: 14px;
            font-weight: 800;
            letter-spacing: 2px;
        """)
        layout.addWidget(self._status_lbl)

        self._sub_lbl = QLabel("Start monitoring to begin scanning")
        self._sub_lbl.setAlignment(Qt.AlignCenter)
        self._sub_lbl.setStyleSheet(f"font-size: 11px; color: {COLORS['text_muted']};")
        layout.addWidget(self._sub_lbl)

        self._apply_level(ThreatLevel.UNKNOWN)

    def set_level(self, level: ThreatLevel, subtitle: str = "") -> None:
        self._level = level
        self._apply_level(level, subtitle)

    def _apply_level(self, level: ThreatLevel, subtitle: str = "") -> None:
        color, icon, text = self._LEVEL_CONFIG.get(
            level, ("#8B9CB8", "?", "UNKNOWN")
        )
        self._icon_lbl.setText(icon)
        self._icon_lbl.setStyleSheet(f"font-size: 36px; color: {color};")
        self._status_lbl.setText(text)
        self._status_lbl.setStyleSheet(f"""
            font-size: 14px;
            font-weight: 800;
            letter-spacing: 2px;
            color: {color};
        """)
        if subtitle:
            self._sub_lbl.setText(subtitle)
        self.setStyleSheet(f"""
            QFrame#threat_badge {{
                background-color: {COLORS['bg_card']};
                border: 2px solid {color};
                border-radius: 12px;
            }}
        """)


class AlertBanner(QFrame):
    """Dismissible alert shown when a threat is detected."""

    def __init__(self, result: ScanResult) -> None:
        super().__init__()
        self.setObjectName("notification_danger" if result.threat_level == ThreatLevel.MALICIOUS
                           else "notification_warning")
        self.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['bg_surface']};
                border-left: 4px solid {'#E53935' if result.threat_level == ThreatLevel.MALICIOUS else '#FFD600'};
                border-radius: 6px;
                margin: 4px 0;
            }}
        """)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 8, 10, 8)

        icon = "🚨" if result.threat_level == ThreatLevel.MALICIOUS else "⚠️"
        icon_lbl = QLabel(icon)
        icon_lbl.setStyleSheet("font-size: 18px;")
        layout.addWidget(icon_lbl)

        vt = result.vt_report
        summary = vt.summary_label if vt else "Unknown detection"
        text_lbl = QLabel(
            f"<b>{result.filename}</b><br>"
            f"<span style='font-size:11px;color:{COLORS['text_secondary']}'>{summary}</span>"
        )
        layout.addWidget(text_lbl, stretch=1)

        dismiss = QPushButton("✕")
        dismiss.setFixedSize(24, 24)
        dismiss.setStyleSheet(f"""
            QPushButton {{
                background: transparent;
                border: none;
                color: {COLORS['text_muted']};
                font-size: 14px;
            }}
            QPushButton:hover {{ color: {COLORS['text_primary']}; }}
        """)
        dismiss.clicked.connect(self.hide)
        layout.addWidget(dismiss)


class DashboardPage(QWidget):
    """
    Main dashboard displaying:
      - Threat level badge
      - KPI stat cards (total / clean / suspicious / malicious)
      - Recent alerts panel
      - Detection activity bar chart (last 7 entries)
    """

    def __init__(self, config: Config, db: DatabaseManager) -> None:
        super().__init__()
        self._config = config
        self._db = db
        self._setup_ui()
        self.refresh()

    # ------------------------------------------------------------------ #
    #  UI Construction                                                     #
    # ------------------------------------------------------------------ #

    def _setup_ui(self) -> None:
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(24, 20, 24, 20)
        main_layout.setSpacing(16)

        # ── Page header ──
        header = QHBoxLayout()
        title = QLabel("Security Dashboard")
        title.setStyleSheet(f"""
            font-size: 20px;
            font-weight: 700;
            color: {COLORS['text_primary']};
        """)
        header.addWidget(title)
        header.addStretch()

        self._timestamp_lbl = QLabel()
        self._timestamp_lbl.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 11px;")
        header.addWidget(self._timestamp_lbl)
        main_layout.addLayout(header)

        # ── Top row: threat badge + stat cards ──
        top_row = QHBoxLayout()
        top_row.setSpacing(14)

        self._threat_badge = ThreatLevelBadge()
        self._threat_badge.setFixedWidth(260)
        top_row.addWidget(self._threat_badge)

        cards_grid = QGridLayout()
        cards_grid.setSpacing(12)

        self._card_total      = StatCard("Total Scans",  icon="📊", color=COLORS["accent_cyan"])
        self._card_clean      = StatCard("Clean",        icon="✅", color=COLORS["success"])
        self._card_suspicious = StatCard("Suspicious",   icon="⚠️", color=COLORS["suspicious"])
        self._card_malicious  = StatCard("Malicious",    icon="🚨", color=COLORS["danger"])

        cards_grid.addWidget(self._card_total,      0, 0)
        cards_grid.addWidget(self._card_clean,      0, 1)
        cards_grid.addWidget(self._card_suspicious, 1, 0)
        cards_grid.addWidget(self._card_malicious,  1, 1)

        top_row.addLayout(cards_grid, stretch=1)
        main_layout.addLayout(top_row)

        # ── Separator ──
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet(f"color: {COLORS['border']};")
        main_layout.addWidget(sep)

        # ── Bottom row: alerts + mini chart ──
        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(16)

        # Alerts panel
        alerts_container = QFrame()
        alerts_container.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['bg_card']};
                border: 1px solid {COLORS['border']};
                border-radius: 10px;
            }}
        """)
        alerts_layout = QVBoxLayout(alerts_container)
        alerts_layout.setContentsMargins(14, 12, 14, 12)

        alerts_header = QLabel("RECENT ALERTS")
        alerts_header.setStyleSheet(f"""
            font-size: 10px;
            font-weight: 700;
            color: {COLORS['text_muted']};
            letter-spacing: 1.5px;
        """)
        alerts_layout.addWidget(alerts_header)

        self._alerts_scroll = QScrollArea()
        self._alerts_scroll.setWidgetResizable(True)
        self._alerts_scroll.setFrameShape(QFrame.NoFrame)
        self._alerts_scroll.setStyleSheet("background: transparent;")
        self._alerts_inner = QWidget()
        self._alerts_inner.setStyleSheet("background: transparent;")
        self._alerts_list = QVBoxLayout(self._alerts_inner)
        self._alerts_list.setSpacing(4)
        self._alerts_list.setContentsMargins(0, 4, 0, 0)

        # "Keine Alerts" Label INNERHALB der Liste
        self._no_alerts_lbl = QLabel("Noch keine Bedrohungen erkannt")
        self._no_alerts_lbl.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 12px; padding: 20px 0;")
        self._no_alerts_lbl.setAlignment(Qt.AlignCenter)
        self._alerts_list.addWidget(self._no_alerts_lbl)
        self._alerts_list.addStretch()

        self._alerts_scroll.setWidget(self._alerts_inner)
        alerts_layout.addWidget(self._alerts_scroll)

        bottom_row.addWidget(alerts_container, stretch=2)

        # Stats panel
        stats_container = QFrame()
        stats_container.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['bg_card']};
                border: 1px solid {COLORS['border']};
                border-radius: 10px;
            }}
        """)
        stats_layout = QVBoxLayout(stats_container)
        stats_layout.setContentsMargins(14, 12, 14, 12)

        stats_header = QLabel("DETECTION BREAKDOWN")
        stats_header.setStyleSheet(f"""
            font-size: 10px;
            font-weight: 700;
            color: {COLORS['text_muted']};
            letter-spacing: 1.5px;
        """)
        stats_layout.addWidget(stats_header)
        stats_layout.addSpacing(10)

        # Progress bars for detection breakdown
        self._pb_clean      = self._make_progress("Clean",      COLORS["success"],    "#pb_success")
        self._pb_suspicious = self._make_progress("Suspicious", COLORS["suspicious"], "#pb_warning")
        self._pb_malicious  = self._make_progress("Malicious",  COLORS["danger"],     "#pb_danger")

        for label, pb, val_lbl in [self._pb_clean, self._pb_suspicious, self._pb_malicious]:
            row = QHBoxLayout()
            lbl = QLabel(label)
            lbl.setFixedWidth(80)
            lbl.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 12px;")
            row.addWidget(lbl)
            row.addWidget(pb, stretch=1)
            row.addWidget(val_lbl)
            stats_layout.addLayout(row)
            stats_layout.addSpacing(6)

        stats_layout.addStretch()

        # Watch path info
        watch_info = QLabel(f"📁 Watching: {self._config.watch_path}")
        watch_info.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 11px;")
        watch_info.setWordWrap(True)
        stats_layout.addWidget(watch_info)

        # VT status
        vt_status = QLabel(
            f"🔑 VirusTotal: {'Connected' if self._config.vt_configured else 'No API key'}"
        )
        vt_color = COLORS["success"] if self._config.vt_configured else COLORS["warning"]
        vt_status.setStyleSheet(f"color: {vt_color}; font-size: 11px;")
        stats_layout.addWidget(vt_status)

        bottom_row.addWidget(stats_container, stretch=1)
        main_layout.addLayout(bottom_row, stretch=1)

    def _make_progress(
        self, label: str, color: str, obj_name: str
    ) -> tuple[str, QProgressBar, QLabel]:
        pb = QProgressBar()
        pb.setRange(0, 100)
        pb.setValue(0)
        pb.setTextVisible(False)
        pb.setFixedHeight(12)
        pb.setObjectName(obj_name.lstrip("#"))
        pb.setStyleSheet(f"""
            QProgressBar {{
                background-color: {COLORS['bg_surface']};
                border: none;
                border-radius: 6px;
            }}
            QProgressBar::chunk {{
                background-color: {color};
                border-radius: 6px;
            }}
        """)
        val_lbl = QLabel("0")
        val_lbl.setFixedWidth(32)
        val_lbl.setAlignment(Qt.AlignRight)
        val_lbl.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
        return label, pb, val_lbl

    # ------------------------------------------------------------------ #
    #  Public API                                                          #
    # ------------------------------------------------------------------ #

    def refresh(self) -> None:
        """Reload stats from the database."""
        stats = self._db.get_stats()
        self._card_total.set_value(stats["total"])
        self._card_clean.set_value(stats["clean"])
        self._card_suspicious.set_value(stats["suspicious"])
        self._card_malicious.set_value(stats["malicious"])

        total = max(stats["total"], 1)
        _, pb_c, lbl_c = self._pb_clean
        _, pb_s, lbl_s = self._pb_suspicious
        _, pb_m, lbl_m = self._pb_malicious

        pb_c.setValue(int(stats["clean"] / total * 100))
        pb_s.setValue(int(stats["suspicious"] / total * 100))
        pb_m.setValue(int(stats["malicious"] / total * 100))

        lbl_c.setText(str(stats["clean"]))
        lbl_s.setText(str(stats["suspicious"]))
        lbl_m.setText(str(stats["malicious"]))

        # Update threat badge based on whether any malicious files were seen
        if stats["malicious"] > 0:
            self._threat_badge.set_level(
                ThreatLevel.MALICIOUS,
                f"{stats['malicious']} malicious file(s) detected"
            )
        elif stats["suspicious"] > 0:
            self._threat_badge.set_level(
                ThreatLevel.SUSPICIOUS,
                f"{stats['suspicious']} suspicious file(s)"
            )
        elif stats["clean"] > 0:
            self._threat_badge.set_level(
                ThreatLevel.CLEAN,
                f"{stats['clean']} file(s) scanned clean"
            )

        self._timestamp_lbl.setText(
            f"Zuletzt aktualisiert: {datetime.now().strftime('%H:%M:%S')}"
        )

        # Lade die letzten Bedrohungen aus der DB beim Refresh
        try:
            recent = self._db.get_recent_scans(limit=50)
            threats = [r for r in recent if r.threat_level.value in ("malicious", "suspicious")]
            if threats and not any(
                self._alerts_list.itemAt(i) and
                not isinstance(self._alerts_list.itemAt(i).widget(), QLabel)
                for i in range(self._alerts_list.count())
            ):
                for threat in threats[:5]:  # Nur die letzten 5 zeigen
                    self.show_alert(threat)
        except Exception:
            pass

    def show_alert(self, result: ScanResult) -> None:
        """Add a new alert banner to the alerts panel."""
        # Verstecke "Keine Bedrohungen" Label
        self._no_alerts_lbl.setVisible(False)

        banner = AlertBanner(result)
        # Immer oben einfügen (nach dem no_alerts_lbl an Position 0)
        self._alerts_list.insertWidget(0, banner)

        # Maximale Anzahl Alerts begrenzen auf 20
        while self._alerts_list.count() > 22:  # 20 alerts + no_alerts_lbl + stretch
            # Letztes Widget vor dem Stretch entfernen
            item = self._alerts_list.takeAt(self._alerts_list.count() - 2)
            if item and item.widget():
                item.widget().deleteLater()

        # Scroll nach oben
        self._alerts_scroll.verticalScrollBar().setValue(0)
