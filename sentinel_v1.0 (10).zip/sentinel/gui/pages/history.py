"""
gui/pages/history.py
====================
Searchable table of all scan results from the database.
"""

from __future__ import annotations

import logging
from datetime import datetime

from PySide6.QtCore import Qt, QTimer, Signal, Slot
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QMessageBox,
    QVBoxLayout,
    QWidget,
)

from core.models import ScanResult, ThreatLevel
from database.db_manager import DatabaseManager
from gui.styles import COLORS

log = logging.getLogger("sentinel.gui.history")

_THREAT_COLORS = {
    ThreatLevel.MALICIOUS:  COLORS["danger"],
    ThreatLevel.SUSPICIOUS: COLORS["suspicious"],
    ThreatLevel.CLEAN:      COLORS["success"],
    ThreatLevel.UNKNOWN:    COLORS["text_muted"],
}

_COLS = [
    ("Filename",   220),
    ("Threat",      90),
    ("Risk",        60),
    ("Detections", 110),
    ("SHA-256",    200),
    ("Size",        80),
    ("Entropy",     70),
    ("Patterns",   140),
    ("Scanned At", 140),
]


class HistoryPage(QWidget):
    """
    Full scan history in a sortable, searchable table.

    Emits ``view_detail_requested`` with the selected ScanResult when
    the user double-clicks a row or clicks "View Details".
    """

    view_detail_requested = Signal(object)  # ScanResult

    def __init__(self, db: DatabaseManager) -> None:
        super().__init__()
        self._db = db
        self._results: list[ScanResult] = []
        self._setup_ui()
        QTimer.singleShot(100, self.refresh)

    # ------------------------------------------------------------------ #
    #  UI Construction                                                     #
    # ------------------------------------------------------------------ #

    def _setup_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(12)

        # Header
        header = QHBoxLayout()
        title = QLabel("Scan History")
        title.setStyleSheet(f"font-size: 20px; font-weight: 700; color: {COLORS['text_primary']};")
        header.addWidget(title)
        header.addStretch()

        refresh_btn = QPushButton("↻ Refresh")
        refresh_btn.setFixedHeight(30)
        refresh_btn.clicked.connect(self.refresh)
        header.addWidget(refresh_btn)
        layout.addLayout(header)

        # Search bar
        search_row = QHBoxLayout()
        self._search = QLineEdit()
        self._search.setPlaceholderText("Search by filename, hash, or pattern…")
        self._search.setClearButtonEnabled(True)
        self._search.setFixedHeight(34)
        self._search.textChanged.connect(self._on_search_changed)
        search_row.addWidget(self._search)

        self._count_lbl = QLabel("0 results")
        self._count_lbl.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 12px;")
        search_row.addWidget(self._count_lbl)

        layout.addLayout(search_row)

        # Filter buttons — direkt unter der Suche, farblich kodiert
        filter_row = QHBoxLayout()
        filter_row.setSpacing(6)

        filter_lbl = QLabel("Filter:")
        filter_lbl.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 12px;")
        filter_row.addWidget(filter_lbl)

        # (label, filter_value, active_color, text_color)
        filter_config = [
            ("Alle",        "all",        COLORS["accent"],     "white"),
            ("Malicious",   "malicious",  COLORS["danger"],     "white"),
            ("Suspicious",  "suspicious", COLORS["suspicious"], "#000000"),
            ("Clean",       "clean",      COLORS["success"],    "white"),
        ]

        self._filter_btns: list[QPushButton] = []
        for label, value, active_color, active_text in filter_config:
            btn = QPushButton(label)
            btn.setMinimumHeight(28)
            btn.setMinimumWidth(80)
            btn.setCheckable(True)
            btn.setChecked(value == "all")
            btn.setProperty("filter_value", value)
            btn.setProperty("active_color", active_color)
            btn.setProperty("active_text", active_text)
            # Stil setzen
            btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {COLORS['bg_surface']};
                    color: {COLORS['text_secondary']};
                    border: 1px solid {COLORS['border']};
                    border-radius: 5px;
                    padding: 3px 12px;
                    font-size: 12px;
                    font-weight: 500;
                }}
                QPushButton:checked {{
                    background-color: {active_color};
                    color: {active_text};
                    border-color: {active_color};
                    font-weight: 700;
                }}
                QPushButton:hover:!checked {{
                    background-color: {COLORS['bg_card']};
                    border-color: {active_color};
                    color: {active_color};
                }}
            """)
            btn.clicked.connect(self._on_filter_clicked)
            self._filter_btns.append(btn)
            filter_row.addWidget(btn)

        filter_row.addStretch()

        export_btn = QPushButton("Export CSV")
        export_btn.setMinimumHeight(28)
        export_btn.setMinimumWidth(100)
        export_btn.clicked.connect(self._export_csv)
        filter_row.addWidget(export_btn)
        layout.addLayout(filter_row)

        # Table
        self._table = QTableWidget()
        self._table.setColumnCount(len(_COLS))
        self._table.setHorizontalHeaderLabels([c[0] for c in _COLS])
        self._table.setAlternatingRowColors(True)
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SingleSelection)
        self._table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._table.verticalHeader().setVisible(False)
        self._table.setShowGrid(False)
        self._table.setSortingEnabled(True)
        self._table.doubleClicked.connect(self._on_row_double_clicked)

        hh = self._table.horizontalHeader()
        for i, (name, width) in enumerate(_COLS):
            self._table.setColumnWidth(i, width)
        hh.setStretchLastSection(False)
        hh.setSectionResizeMode(0, QHeaderView.Stretch)

        layout.addWidget(self._table, stretch=1)

        # Bottom bar — zweizeilig damit Buttons nicht abgeschnitten werden
        bottom_frame = QFrame()
        bottom_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['bg_card']};
                border: 1px solid {COLORS['border']};
                border-radius: 8px;
            }}
        """)
        bottom_outer = QVBoxLayout(bottom_frame)
        bottom_outer.setContentsMargins(12, 8, 12, 8)
        bottom_outer.setSpacing(6)

        # Zeile 1: Info-Text
        self._selected_info = QLabel("Zeile auswählen um Aktionen zu sehen")
        self._selected_info.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 11px;")
        bottom_outer.addWidget(self._selected_info)

        # Zeile 2: Buttons
        bottom = QHBoxLayout()
        bottom.setSpacing(8)

        self._view_btn = QPushButton("🔍  Details anzeigen")
        self._view_btn.setObjectName("btn_primary")
        self._view_btn.setMinimumHeight(32)
        self._view_btn.setMinimumWidth(140)
        self._view_btn.setEnabled(False)
        self._view_btn.clicked.connect(self._on_view_clicked)
        bottom.addWidget(self._view_btn)

        self._quarantine_btn = QPushButton("🗂  Quarantäne")
        self._quarantine_btn.setMinimumHeight(32)
        self._quarantine_btn.setMinimumWidth(120)
        self._quarantine_btn.setEnabled(False)
        self._quarantine_btn.setToolTip("Datei in Quarantäne verschieben (nicht löschen)")
        self._quarantine_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['bg_surface']};
                color: {COLORS['warning']};
                border: 1px solid {COLORS['warning']};
                border-radius: 6px;
                padding: 4px 14px;
                font-size: 12px;
            }}
            QPushButton:hover {{
                background-color: {COLORS['warning']};
                color: white;
            }}
            QPushButton:disabled {{
                color: {COLORS['text_muted']};
                border-color: {COLORS['border']};
                background-color: {COLORS['bg_surface']};
            }}
        """)
        self._quarantine_btn.clicked.connect(self._on_quarantine_clicked)
        bottom.addWidget(self._quarantine_btn)

        self._delete_btn = QPushButton("🗑  Datei löschen")
        self._delete_btn.setMinimumHeight(32)
        self._delete_btn.setMinimumWidth(120)
        self._delete_btn.setEnabled(False)
        self._delete_btn.setToolTip("Datei dauerhaft vom Datenträger löschen")
        self._delete_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['bg_surface']};
                color: {COLORS['danger']};
                border: 1px solid {COLORS['danger']};
                border-radius: 6px;
                padding: 4px 14px;
                font-size: 12px;
            }}
            QPushButton:hover {{
                background-color: {COLORS['danger']};
                color: white;
            }}
            QPushButton:disabled {{
                color: {COLORS['text_muted']};
                border-color: {COLORS['border']};
                background-color: {COLORS['bg_surface']};
            }}
        """)
        self._delete_btn.clicked.connect(self._on_delete_clicked)
        bottom.addWidget(self._delete_btn)

        bottom.addStretch()
        bottom_outer.addLayout(bottom)
        layout.addWidget(bottom_frame)

        self._table.itemSelectionChanged.connect(self._on_selection_changed)

    # ------------------------------------------------------------------ #
    #  Data                                                                #
    # ------------------------------------------------------------------ #

    def refresh(self) -> None:
        """Reload history from the database."""
        self._results = self._db.get_recent_scans(limit=500)
        self._apply_display()

    def prepend_result(self, result: ScanResult) -> None:
        """Add a new result at the top without full reload."""
        # Check if already present (by id or filename)
        existing_ids = {r.id for r in self._results if r.id}
        if result.id in existing_ids:
            # Update in place
            for i, r in enumerate(self._results):
                if r.id == result.id:
                    self._results[i] = result
                    break
        else:
            self._results.insert(0, result)
        self._apply_display()

    def _apply_display(self) -> None:
        """Re-render the table from self._results with current filters."""
        query = self._search.text().strip()
        active_filter = next(
            (b.property("filter_value") for b in self._filter_btns if b.isChecked()),
            "all"
        )

        # Filter
        display = self._results
        if query:
            ql = query.lower()
            display = [
                r for r in display
                if ql in r.filename.lower()
                or (r.metadata and ql in r.metadata.sha256.lower())
                or (r.metadata and any(ql in p.lower() for p in r.metadata.suspicious_patterns))
            ]
        if active_filter != "all":
            display = [r for r in display if r.threat_level.value == active_filter]

        # Populate table
        self._table.setSortingEnabled(False)
        self._table.setRowCount(len(display))

        for row, result in enumerate(display):
            self._fill_row(row, result)

        self._table.setSortingEnabled(True)
        self._count_lbl.setText(f"{len(display):,} result{'s' if len(display) != 1 else ''}")

    def _fill_row(self, row: int, result: ScanResult) -> None:
        """Populate a single table row."""
        level = result.threat_level
        color_str = _THREAT_COLORS.get(level, COLORS["text_muted"])
        q_color = QColor(color_str)

        meta = result.metadata
        vt = result.vt_report

        def cell(text: str, align=Qt.AlignLeft) -> QTableWidgetItem:
            item = QTableWidgetItem(text)
            item.setTextAlignment(align | Qt.AlignVCenter)
            item.setData(Qt.UserRole, result)  # store result on first column
            return item

        # 0: Filename
        self._table.setItem(row, 0, cell(result.filename))

        # 1: Threat level
        threat_item = cell(level.value.upper(), Qt.AlignCenter)
        threat_item.setForeground(q_color)
        self._table.setItem(row, 1, threat_item)

        # 2: Risk score
        risk_item = cell(str(result.risk_score), Qt.AlignCenter)
        risk_color = (
            QColor(COLORS["danger"])     if result.risk_score >= 75 else
            QColor(COLORS["warning"])    if result.risk_score >= 40 else
            QColor(COLORS["suspicious"]) if result.risk_score >= 10 else
            QColor(COLORS["success"])
        )
        risk_item.setForeground(risk_color)
        self._table.setItem(row, 2, risk_item)

        # 3: Detections
        if vt and vt.total_engines > 0:
            det = f"{vt.malicious + vt.suspicious}/{vt.total_engines}"
        else:
            det = "—"
        self._table.setItem(row, 3, cell(det, Qt.AlignCenter))

        # 4: SHA-256 (truncated)
        sha = meta.sha256[:24] + "…" if meta and meta.sha256 else "—"
        self._table.setItem(row, 4, cell(sha))

        # 5: Size
        size = f"{meta.size_bytes:,}" if meta else "—"
        self._table.setItem(row, 5, cell(size, Qt.AlignRight))

        # 6: Entropy
        entropy = f"{meta.entropy:.2f}" if meta else "—"
        self._table.setItem(row, 6, cell(entropy, Qt.AlignCenter))

        # 7: Patterns
        patterns = ", ".join(meta.suspicious_patterns[:3]) if meta else ""
        self._table.setItem(row, 7, cell(patterns or "—"))

        # 8: Scanned at
        ts = result.scanned_at.strftime("%Y-%m-%d %H:%M") if result.scanned_at else "—"
        self._table.setItem(row, 8, cell(ts))

    # ------------------------------------------------------------------ #
    #  Event handlers                                                      #
    # ------------------------------------------------------------------ #

    def _on_search_changed(self, text: str) -> None:
        self._apply_display()

    def _on_filter_clicked(self) -> None:
        sender = self.sender()
        for btn in self._filter_btns:
            btn.setChecked(btn is sender)
        self._apply_display()

    def _on_selection_changed(self) -> None:
        rows = self._table.selectedItems()
        has_selection = bool(rows)
        self._view_btn.setEnabled(has_selection)
        self._delete_btn.setEnabled(has_selection)
        self._quarantine_btn.setEnabled(has_selection)
        if rows:
            result = rows[0].data(Qt.UserRole)
            if result:
                from pathlib import Path
                file_exists = Path(result.file_path).exists() if result.file_path else False
                self._delete_btn.setEnabled(file_exists)
                self._quarantine_btn.setEnabled(file_exists)
                self._selected_info.setText(
                    f"Ausgewählt: {result.filename}  |  Risiko: {result.risk_score}"
                    + ("" if file_exists else "  |  ⚠ Datei nicht mehr vorhanden")
                )

    def _on_row_double_clicked(self) -> None:
        self._on_view_clicked()

    def _on_view_clicked(self) -> None:
        rows = self._table.selectedItems()
        if rows:
            result = rows[0].data(Qt.UserRole)
            if result:
                self.view_detail_requested.emit(result)

    def _on_delete_clicked(self) -> None:
        """Dauerhaft die Originaldatei vom Datenträger löschen — nach Bestätigung."""
        rows = self._table.selectedItems()
        if not rows:
            return
        result = rows[0].data(Qt.UserRole)
        if not result:
            return

        from pathlib import Path
        file_path = Path(result.file_path)

        reply = QMessageBox.warning(
            self,
            "Datei löschen",
            f"Soll diese Datei dauerhaft gelöscht werden?\n\n"
            f"📄  {result.filename}\n"
            f"📁  {result.file_path}\n\n"
            f"⚠️  Diese Aktion kann NICHT rückgängig gemacht werden!",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return

        try:
            if file_path.exists():
                file_path.unlink()
                QMessageBox.information(
                    self, "Gelöscht",
                    f"✅  Datei wurde gelöscht:\n{result.filename}"
                )
                log.info("User deleted file: %s", file_path)
            else:
                QMessageBox.warning(
                    self, "Nicht gefunden",
                    f"Die Datei existiert nicht mehr:\n{result.file_path}"
                )
        except PermissionError:
            QMessageBox.critical(
                self, "Fehler",
                f"❌  Keine Berechtigung zum Löschen:\n{result.filename}\n\n"
                f"Versuche es als Administrator."
            )
        except Exception as exc:
            QMessageBox.critical(self, "Fehler", f"Löschen fehlgeschlagen:\n{exc}")

        # Buttons deaktivieren da Datei weg ist
        self._delete_btn.setEnabled(False)
        self._quarantine_btn.setEnabled(False)

    def _on_quarantine_clicked(self) -> None:
        """Datei in Quarantäne verschieben (sicherer als löschen)."""
        rows = self._table.selectedItems()
        if not rows:
            return
        result = rows[0].data(Qt.UserRole)
        if not result:
            return

        from pathlib import Path
        file_path = Path(result.file_path)

        reply = QMessageBox.question(
            self,
            "In Quarantäne verschieben",
            f"Datei in Quarantäne verschieben?\n\n"
            f"📄  {result.filename}\n\n"
            f"Die Datei kann später wiederhergestellt werden.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )
        if reply != QMessageBox.Yes:
            return

        try:
            from utils.quarantine import QuarantineManager
            from core.config import Config
            cfg = Config()
            qmgr = QuarantineManager(cfg.quarantine_dir)
            sha256 = result.metadata.sha256 if result.metadata else ""
            dest = qmgr.quarantine(file_path, sha256=sha256, reason="manual via history")
            QMessageBox.information(
                self, "Quarantäne",
                f"✅  Datei in Quarantäne verschoben:\n{dest.name}\n\n"
                f"Speicherort:\n{dest}"
            )
            log.info("User quarantined file: %s → %s", file_path, dest)
        except FileNotFoundError:
            QMessageBox.warning(self, "Nicht gefunden",
                                f"Datei existiert nicht mehr:\n{result.file_path}")
        except Exception as exc:
            QMessageBox.critical(self, "Fehler", f"Quarantäne fehlgeschlagen:\n{exc}")

        self._delete_btn.setEnabled(False)
        self._quarantine_btn.setEnabled(False)

    def _export_csv(self) -> None:
        from PySide6.QtWidgets import QFileDialog
        from pathlib import Path
        path, _ = QFileDialog.getSaveFileName(
            self, "Export CSV", str(Path.home() / "sentinel_history.csv"), "CSV (*.csv)"
        )
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                headers = [c[0] for c in _COLS]
                f.write(",".join(headers) + "\n")
                for r in self._results:
                    vt = r.vt_report
                    meta = r.metadata
                    det = f"{vt.malicious}/{vt.total_engines}" if vt and vt.total_engines else ""
                    row_data = [
                        r.filename,
                        r.threat_level.value,
                        str(r.risk_score),
                        det,
                        meta.sha256 if meta else "",
                        str(meta.size_bytes) if meta else "",
                        f"{meta.entropy:.2f}" if meta else "",
                        "|".join(meta.suspicious_patterns) if meta else "",
                        r.scanned_at.isoformat() if r.scanned_at else "",
                    ]
                    f.write(",".join(f'"{v}"' for v in row_data) + "\n")
        except Exception as exc:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Export Error", str(exc))
