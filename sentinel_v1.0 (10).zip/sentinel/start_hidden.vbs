Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

' Sentinel Ordner
strDir = objFSO.GetParentFolderName(WScript.ScriptFullName)

' Python aus .venv starten (verstecktes Fenster)
strCmd = strDir & "\.venv\Scripts\pythonw.exe " & strDir & "\main.py"
objShell.CurrentDirectory = strDir
objShell.Run strCmd, 0, False
