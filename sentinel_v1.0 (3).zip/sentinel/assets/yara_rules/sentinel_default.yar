/*
 * Sentinel YARA Rules — Educational Examples
 * ===========================================
 * These rules detect common malicious patterns in files.
 * They are PURELY for detection/alerting — Sentinel never
 * deletes or executes any matched file.
 *
 * Place additional .yar files in this directory and they
 * will be loaded automatically on startup.
 */

rule SuspiciousPowerShellDownload
{
    meta:
        description = "Detects PowerShell download cradles"
        severity    = "high"
        author      = "Sentinel"

    strings:
        $ps1 = "DownloadString" nocase
        $ps2 = "DownloadFile"   nocase
        $ps3 = "WebClient"      nocase
        $ps4 = "Invoke-Expression" nocase
        $ps5 = "IEX("           nocase

    condition:
        2 of ($ps*)
}

rule Base64EncodedPayload
{
    meta:
        description = "Detects suspiciously long Base64 blobs (possible encoded payload)"
        severity    = "medium"

    strings:
        // Long Base64 string (60+ chars) — typical of encoded shellcode
        $b64 = /[A-Za-z0-9+\/]{60,}={0,2}/

    condition:
        #b64 >= 3
}

rule MimikatzStrings
{
    meta:
        description = "Detects strings associated with Mimikatz credential dumper"
        severity    = "critical"
        reference   = "https://github.com/gentilkiwi/mimikatz"

    strings:
        $m1 = "sekurlsa"     nocase
        $m2 = "kerberos"     nocase
        $m3 = "mimikatz"     nocase
        $m4 = "lsadump"      nocase
        $m5 = "wdigest"      nocase
        $m6 = "logonpasswords" nocase

    condition:
        2 of ($m*)
}

rule SuspiciousRegistryPersistence
{
    meta:
        description = "Detects registry-based persistence mechanisms"
        severity    = "high"

    strings:
        $r1 = "CurrentVersion\\Run"    nocase wide ascii
        $r2 = "CurrentVersion\\RunOnce" nocase wide ascii
        $r3 = "Software\\Microsoft\\Windows\\CurrentVersion\\Run" nocase wide ascii

    condition:
        any of ($r*)
}

rule ObfuscatedScript
{
    meta:
        description = "Detects heavily obfuscated script content"
        severity    = "medium"

    strings:
        $chr  = "Chr(" nocase
        $fromB = "FromBase64String" nocase
        $env  = "[Environment]::" nocase
        $exec = "ExecutionPolicy Bypass" nocase

    condition:
        2 of them
}

rule SuspiciousCertutilUsage
{
    meta:
        description = "Detects certutil being used for file decoding (LOLBin)"
        severity    = "high"

    strings:
        $c1 = "certutil" nocase
        $c2 = "-decode"  nocase
        $c3 = "-urlcache" nocase

    condition:
        $c1 and ($c2 or $c3)
}

rule RansomwareExtensionAppend
{
    meta:
        description = "Detects file extension strings common in ransomware notes"
        severity    = "critical"

    strings:
        $r1 = "YOUR_FILES_ARE_ENCRYPTED" nocase
        $r2 = "HOW_TO_DECRYPT"           nocase
        $r3 = "RECOVERY_INSTRUCTIONS"    nocase
        $r4 = "bitcoin"                  nocase
        $r5 = "BTC wallet"               nocase

    condition:
        2 of ($r*)
}

rule SuspiciousNetworkActivity
{
    meta:
        description = "Detects suspicious outbound connection strings"
        severity    = "medium"

    strings:
        $n1 = "socket.connect" nocase
        $n2 = "WSAStartup"     nocase
        $n3 = "raw_input"      nocase
        $n4 = "nc.exe"         nocase
        $n5 = "ncat"           nocase

    condition:
        2 of ($n*)
}
