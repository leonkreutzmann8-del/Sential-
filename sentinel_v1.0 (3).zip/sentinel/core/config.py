"""
core/config.py
==============
Centralised configuration for Sentinel.

All configurable values live here.  Values are read from:
  1. Environment variables
  2. A .env file in the project root  (python-dotenv)
  3. Hard-coded defaults below

Never hard-code secrets directly.  Put your VirusTotal API key in .env:
    SENTINEL_VT_API_KEY=<your_key_here>
"""

from __future__ import annotations

import os
import logging
from dataclasses import dataclass, field
from pathlib import Path

# Try to load .env if present (optional dependency gracefully handled)
try:
    from dotenv import load_dotenv
    _env_file = Path(__file__).parent.parent / ".env"
    if _env_file.exists():
        load_dotenv(_env_file)
except ImportError:
    pass  # python-dotenv not installed — that's fine

log = logging.getLogger("sentinel.config")



def _default_downloads() -> str:
    """
    Return the user's Downloads folder path.
    On Windows, uses the Shell known-folders API so it works even if
    the user moved their Downloads folder away from the default location.
    Falls back to ~/Downloads on other platforms.
    """
    import sys
    if sys.platform == "win32":
        try:
            import ctypes, ctypes.wintypes
            # FOLDERID_Downloads = {374DE290-123F-4565-9164-39C4925E467B}
            SHGetKnownFolderPath = ctypes.windll.shell32.SHGetKnownFolderPath
            SHGetKnownFolderPath.argtypes = [
                ctypes.c_char_p, ctypes.wintypes.DWORD,
                ctypes.wintypes.HANDLE, ctypes.POINTER(ctypes.c_wchar_p)
            ]
            FOLDERID_Downloads = "{374DE290-123F-4565-9164-39C4925E467B}"
            path_ptr = ctypes.c_wchar_p()
            import comtypes  # type: ignore
            guid = comtypes.GUID(FOLDERID_Downloads)
            SHGetKnownFolderPath(guid, 0, None, ctypes.byref(path_ptr))
            if path_ptr.value:
                return path_ptr.value
        except Exception:
            pass
        # Simpler Windows fallback using environment variables
        userprofile = os.environ.get("USERPROFILE", "")
        if userprofile:
            return str(Path(userprofile) / "Downloads")
    return str(Path.home() / "Downloads")

@dataclass
class Config:
    """
    Application-wide settings.

    Attributes
    ----------
    vt_api_key : str
        VirusTotal public API key.  Required for VT features.
    watch_path : Path
        Folder to monitor (defaults to ~/Downloads).
    db_path : Path
        SQLite database file location.
    vt_rate_limit : int
        Maximum VT API requests per minute (public API = 4).
    vt_poll_interval : int
        Seconds between status polls when waiting for analysis.
    vt_poll_max_attempts : int
        Give up after this many polls.
    min_file_size : int
        Skip files smaller than this (bytes).  Avoids noise from 0-byte
        temp files.
    max_upload_size : int
        Do not upload files larger than this to VT (bytes).
        Public API limit is 32 MB.
    ignored_extensions : frozenset
        Browser temp-file extensions to skip.
    reports_dir : Path
        Where PDF scan reports are saved.
    quarantine_dir : Path
        Where quarantined files are moved.
    yara_rules_dir : Path
        Directory containing YARA .yar / .yrc rule files.
    """

    # ------------------------------------------------------------------ #
    #  VirusTotal                                                          #
    # ------------------------------------------------------------------ #
    vt_api_key: str = field(
        default_factory=lambda: os.environ.get("SENTINEL_VT_API_KEY", "")
    )
    vt_rate_limit: int = field(
        default_factory=lambda: int(os.environ.get("SENTINEL_VT_RATE_LIMIT", "4"))
    )
    vt_poll_interval: int = field(
        default_factory=lambda: int(os.environ.get("SENTINEL_VT_POLL_INTERVAL", "15"))
    )
    vt_poll_max_attempts: int = field(
        default_factory=lambda: int(
            os.environ.get("SENTINEL_VT_POLL_MAX_ATTEMPTS", "12")
        )
    )

    # ------------------------------------------------------------------ #
    #  Paths                                                               #
    # ------------------------------------------------------------------ #
    watch_path: Path = field(
        default_factory=lambda: Path(
            os.environ.get("SENTINEL_WATCH_PATH", "") or _default_downloads()
        )
    )
    db_path: Path = field(
        default_factory=lambda: Path(
            os.environ.get(
                "SENTINEL_DB_PATH",
                str(Path.home() / ".sentinel" / "sentinel.db"),
            )
        )
    )
    reports_dir: Path = field(
        default_factory=lambda: Path(
            os.environ.get(
                "SENTINEL_REPORTS_DIR",
                str(Path.home() / ".sentinel" / "reports"),
            )
        )
    )
    quarantine_dir: Path = field(
        default_factory=lambda: Path(
            os.environ.get(
                "SENTINEL_QUARANTINE_DIR",
                str(Path.home() / ".sentinel" / "quarantine"),
            )
        )
    )
    yara_rules_dir: Path = field(
        default_factory=lambda: Path(
            os.environ.get(
                "SENTINEL_YARA_RULES_DIR",
                str(Path(__file__).parent.parent / "assets" / "yara_rules"),
            )
        )
    )

    # ------------------------------------------------------------------ #
    #  File filtering                                                      #
    # ------------------------------------------------------------------ #
    min_file_size: int = field(
        default_factory=lambda: int(
            os.environ.get("SENTINEL_MIN_FILE_SIZE", "64")
        )
    )
    max_upload_size: int = field(
        default_factory=lambda: int(
            os.environ.get("SENTINEL_MAX_UPLOAD_SIZE", str(32 * 1024 * 1024))
        )
    )

    # Browser / OS temporary file extensions to ignore
    ignored_extensions: frozenset = field(
        default_factory=lambda: frozenset(
            {
                ".crdownload",  # Chrome partial download
                ".part",        # Firefox partial download
                ".tmp",
                ".temp",
                ".download",    # Safari partial download
                ".opdownload",  # Opera partial download
                ".!ut",         # µTorrent temp
                ".bc!",         # BitComet temp
            }
        )
    )

    def __post_init__(self) -> None:
        """Convert string paths to Path objects and ensure dirs exist."""
        # Coerce str → Path (handles env-var injections)
        for attr in ("watch_path", "db_path", "reports_dir", "quarantine_dir", "yara_rules_dir"):
            val = getattr(self, attr)
            if isinstance(val, str):
                setattr(self, attr, Path(val))

        # Create directories if they don't exist
        for attr in ("reports_dir", "quarantine_dir", "yara_rules_dir"):
            d: Path = getattr(self, attr)
            d.mkdir(parents=True, exist_ok=True)

        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        if not self.vt_api_key:
            log.warning(
                "No VirusTotal API key configured.  "
                "Set SENTINEL_VT_API_KEY in .env or environment variables."
            )

    # ------------------------------------------------------------------ #
    #  Convenience                                                         #
    # ------------------------------------------------------------------ #
    @property
    def vt_configured(self) -> bool:
        """True when a non-empty VT API key is present."""
        return bool(self.vt_api_key)
