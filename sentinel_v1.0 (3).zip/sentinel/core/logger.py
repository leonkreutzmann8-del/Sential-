"""
core/logger.py
==============
Structured logging setup for Sentinel.

Provides coloured console output (via colorlog) and a rotating file handler
so that debug information is captured without filling the user's disk.
"""

from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path


def setup_logging(
    log_dir: Path | None = None,
    console_level: int = logging.INFO,
    file_level: int = logging.DEBUG,
) -> None:
    """
    Configure root logger with:
      - Coloured console handler (INFO+)
      - Rotating file handler (DEBUG+)  saved to ~/.sentinel/sentinel.log

    Parameters
    ----------
    log_dir:
        Directory for the log file.  Defaults to ~/.sentinel.
    console_level:
        Minimum severity printed to the terminal.
    file_level:
        Minimum severity written to the log file.
    """

    if log_dir is None:
        log_dir = Path.home() / ".sentinel"
    log_dir.mkdir(parents=True, exist_ok=True)

    log_file = log_dir / "sentinel.log"

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)  # handlers control what actually appears

    # Remove any handlers already attached (e.g. added by libraries)
    root.handlers.clear()

    # ------------------------------------------------------------------
    # Console handler — coloured if colorlog is available
    # ------------------------------------------------------------------
    try:
        import colorlog  # type: ignore

        console_fmt = colorlog.ColoredFormatter(
            "%(log_color)s%(asctime)s [%(levelname)-8s]%(reset)s "
            "%(cyan)s%(name)-30s%(reset)s %(message)s",
            datefmt="%H:%M:%S",
            log_colors={
                "DEBUG": "white",
                "INFO": "green",
                "WARNING": "yellow",
                "ERROR": "red",
                "CRITICAL": "bold_red",
            },
        )
    except ImportError:
        console_fmt = logging.Formatter(
            "%(asctime)s [%(levelname)-8s] %(name)-30s %(message)s",
            datefmt="%H:%M:%S",
        )

    console_handler = logging.StreamHandler()
    console_handler.setLevel(console_level)
    console_handler.setFormatter(console_fmt)
    root.addHandler(console_handler)

    # ------------------------------------------------------------------
    # Rotating file handler — 5 MB per file, keep 3 backups
    # ------------------------------------------------------------------
    file_fmt = logging.Formatter(
        "%(asctime)s [%(levelname)-8s] %(name)-35s  %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    file_handler = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=5 * 1024 * 1024,
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setLevel(file_level)
    file_handler.setFormatter(file_fmt)
    root.addHandler(file_handler)

    # Quiet noisy third-party loggers
    for noisy in ("watchdog", "urllib3", "httpx", "httpcore"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    logging.getLogger("sentinel").info(
        "Logging initialised — console: %s | file: %s",
        logging.getLevelName(console_level),
        log_file,
    )
