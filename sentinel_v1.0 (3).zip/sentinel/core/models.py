"""
core/models.py
==============
Pure-Python data classes shared across all layers of Sentinel.

These are intentionally dependency-free so they can be imported
anywhere without risking circular imports.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from pathlib import Path
from typing import Optional


# ========================================================================== #
#  Enumerations                                                               #
# ========================================================================== #

class ThreatLevel(str, Enum):
    """Overall risk categorisation for a scanned file."""
    UNKNOWN    = "unknown"     # Not yet scanned / no data
    CLEAN      = "clean"       # 0 detections
    SUSPICIOUS = "suspicious"  # 1–4 detections or suspicious patterns
    MALICIOUS  = "malicious"   # 5+ detections


class ScanStatus(str, Enum):
    """Lifecycle state of a single scan job."""
    QUEUED    = "queued"
    HASHING   = "hashing"
    VT_LOOKUP = "vt_lookup"
    UPLOADING = "uploading"
    POLLING   = "polling"
    COMPLETE  = "complete"
    ERROR     = "error"
    SKIPPED   = "skipped"


# ========================================================================== #
#  File metadata produced by the local scanner                               #
# ========================================================================== #

@dataclass
class FileMetadata:
    """
    Everything Sentinel can determine about a file WITHOUT calling any
    external service.

    Produced by :class:`scanner.file_analyzer.FileAnalyzer`.
    """

    path: Path

    # Hashes
    sha256: str = ""
    md5: str = ""

    # Basic attributes
    size_bytes: int = 0
    extension: str = ""
    mime_type: str = ""

    # Entropy  (0.0 – 8.0; packed/encrypted files tend towards 7.9+)
    entropy: float = 0.0

    # Strings extracted from the binary (printable ASCII runs ≥ 6 chars)
    strings: list[str] = field(default_factory=list)

    # Which suspicious keyword patterns were found
    suspicious_patterns: list[str] = field(default_factory=list)

    # YARA matches (rule names)
    yara_matches: list[str] = field(default_factory=list)

    # When analysis was performed
    analyzed_at: datetime = field(default_factory=datetime.utcnow)

    @property
    def filename(self) -> str:
        return self.path.name

    @property
    def is_suspicious_locally(self) -> bool:
        """True if local heuristics raised any flags."""
        return bool(self.suspicious_patterns or self.yara_matches or self.entropy > 7.2)


# ========================================================================== #
#  VirusTotal result structures                                               #
# ========================================================================== #

@dataclass
class EngineResult:
    """Result from a single AV engine reported by VirusTotal."""
    engine_name: str
    category: str          # "malicious" | "suspicious" | "undetected" | "timeout"
    result: Optional[str]  # Threat name, e.g. "Trojan.GenericKD.12345"
    engine_version: str = ""
    update: str = ""


@dataclass
class VTReport:
    """
    Parsed VirusTotal file-analysis report.

    Produced by :class:`vt_api.vt_client.VTClient`.
    """

    sha256: str = ""
    meaningful_name: str = ""

    # Detection counts
    malicious: int = 0
    suspicious: int = 0
    undetected: int = 0
    harmless: int = 0
    timeout: int = 0

    # All engine results keyed by engine name
    engine_results: list[EngineResult] = field(default_factory=list)

    # Community reputation score  (-100 … +100)
    reputation: int = 0

    # When VT last analysed this file (may differ from our scan time)
    last_analysis_date: Optional[datetime] = None

    # Raw analysis ID (used for polling)
    analysis_id: str = ""

    # True if we uploaded the file (vs hash-only lookup)
    uploaded: bool = False

    # True if VT had never seen this file before our upload
    first_submission: bool = False

    @property
    def total_engines(self) -> int:
        return self.malicious + self.suspicious + self.undetected + self.harmless + self.timeout

    @property
    def detection_ratio(self) -> float:
        """Fraction of engines that flagged the file (0.0–1.0)."""
        if self.total_engines == 0:
            return 0.0
        return (self.malicious + self.suspicious) / self.total_engines

    @property
    def threat_level(self) -> ThreatLevel:
        if self.total_engines == 0:
            return ThreatLevel.UNKNOWN
        if self.malicious >= 5:
            return ThreatLevel.MALICIOUS
        if self.malicious >= 1 or self.suspicious >= 3:
            return ThreatLevel.SUSPICIOUS
        return ThreatLevel.CLEAN

    @property
    def summary_label(self) -> str:
        """Human-readable detection summary."""
        if self.total_engines == 0:
            return "No scan data"
        detections = self.malicious + self.suspicious
        return f"Detected by {detections}/{self.total_engines} antivirus engines"

    @property
    def flagging_engines(self) -> list[EngineResult]:
        """Only the engines that reported malicious or suspicious."""
        return [e for e in self.engine_results if e.category in ("malicious", "suspicious")]


# ========================================================================== #
#  Scan result — top-level record stored in the database                     #
# ========================================================================== #

@dataclass
class ScanResult:
    """
    Complete record for one file-scan event.

    This is the object persisted to SQLite and displayed in the GUI.
    """

    # Identity
    id: Optional[int] = None          # DB primary key (assigned on save)
    file_path: str = ""
    filename: str = ""

    # Scan lifecycle
    status: ScanStatus = ScanStatus.QUEUED
    threat_level: ThreatLevel = ThreatLevel.UNKNOWN
    scanned_at: datetime = field(default_factory=datetime.utcnow)

    # Metadata sub-records
    metadata: Optional[FileMetadata] = None
    vt_report: Optional[VTReport] = None

    # Error info if status == ERROR
    error_message: str = ""

    # Risk score 0–100 (calculated heuristically)
    risk_score: int = 0

    def compute_risk_score(self) -> int:
        """
        Heuristic risk score combining VT detections and local signals.

        Scale:
          0  = completely clean
          1–25   = minimal concern
          26–50  = low risk
          51–75  = medium risk
          76–100 = high risk / likely malicious
        """
        score = 0

        if self.vt_report:
            vt = self.vt_report
            if vt.total_engines > 0:
                # VT detection ratio is the primary driver (max 70 pts)
                score += int(vt.detection_ratio * 70)
                # Reputation penalty (VT community score, inverted)
                if vt.reputation < -10:
                    score += min(15, abs(vt.reputation) // 5)

        if self.metadata:
            m = self.metadata
            # High entropy suggests packing/encryption (max 10 pts)
            if m.entropy > 7.5:
                score += 10
            elif m.entropy > 7.0:
                score += 5
            # Suspicious string patterns (max 10 pts)
            score += min(10, len(m.suspicious_patterns) * 3)
            # YARA matches
            score += min(10, len(m.yara_matches) * 5)

        self.risk_score = min(100, score)
        return self.risk_score
