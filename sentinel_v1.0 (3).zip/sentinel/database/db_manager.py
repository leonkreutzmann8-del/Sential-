"""
database/db_manager.py
======================
SQLite persistence layer for Sentinel.

Schema
------
  scans           — one row per scan event
  engine_results  — per-engine VT detections (FK → scans)
  hash_cache      — quick lookup: sha256 → was it ever malicious?

All heavy objects (FileMetadata.strings, VTReport.engine_results) are
stored as JSON blobs to keep the schema simple and migration-free.

SECURITY NOTE
-------------
No file content is ever stored — only hashes, metadata, and VT verdicts.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional

from core.models import (
    EngineResult,
    FileMetadata,
    ScanResult,
    ScanStatus,
    ThreatLevel,
    VTReport,
)

log = logging.getLogger("sentinel.database.db_manager")

# ---------------------------------------------------------------------------
# DDL
# ---------------------------------------------------------------------------

_CREATE_SCANS = """
CREATE TABLE IF NOT EXISTS scans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path       TEXT    NOT NULL,
    filename        TEXT    NOT NULL,
    status          TEXT    NOT NULL DEFAULT 'unknown',
    threat_level    TEXT    NOT NULL DEFAULT 'unknown',
    risk_score      INTEGER NOT NULL DEFAULT 0,
    error_message   TEXT    NOT NULL DEFAULT '',
    scanned_at      TEXT    NOT NULL,

    -- FileMetadata fields
    sha256          TEXT,
    md5             TEXT,
    size_bytes      INTEGER,
    extension       TEXT,
    mime_type       TEXT,
    entropy         REAL,
    strings_json    TEXT,   -- JSON array of extracted strings
    patterns_json   TEXT,   -- JSON array of suspicious pattern names
    yara_json       TEXT,   -- JSON array of YARA rule names

    -- VTReport aggregate fields
    vt_malicious    INTEGER,
    vt_suspicious   INTEGER,
    vt_undetected   INTEGER,
    vt_harmless     INTEGER,
    vt_timeout      INTEGER,
    vt_reputation   INTEGER,
    vt_name         TEXT,
    vt_last_date    TEXT,
    vt_uploaded     INTEGER DEFAULT 0,
    vt_analysis_id  TEXT,
    vt_engines_json TEXT    -- JSON array of EngineResult dicts
);
"""

_CREATE_HASH_CACHE = """
CREATE TABLE IF NOT EXISTS hash_cache (
    sha256          TEXT PRIMARY KEY,
    threat_level    TEXT NOT NULL,
    last_seen       TEXT NOT NULL
);
"""

_CREATE_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_scans_sha256 ON scans(sha256);",
    "CREATE INDEX IF NOT EXISTS idx_scans_scanned_at ON scans(scanned_at);",
    "CREATE INDEX IF NOT EXISTS idx_scans_threat ON scans(threat_level);",
]


class DatabaseManager:
    """
    Thread-safe SQLite access using per-thread connections.

    Parameters
    ----------
    db_path : Path
        Filesystem path for the SQLite database file.
    """

    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path
        self._local = threading.local()  # per-thread connection storage

    # ------------------------------------------------------------------ #
    #  Lifecycle                                                           #
    # ------------------------------------------------------------------ #

    def initialize(self) -> None:
        """Create tables and indexes if they don't exist."""
        conn = self._conn()
        conn.execute(_CREATE_SCANS)
        conn.execute(_CREATE_HASH_CACHE)
        for idx_sql in _CREATE_INDEXES:
            conn.execute(idx_sql)
        conn.commit()
        log.info("Database initialised at %s", self._db_path)

    # ------------------------------------------------------------------ #
    #  Connection management                                               #
    # ------------------------------------------------------------------ #

    def _conn(self) -> sqlite3.Connection:
        """Return the thread-local SQLite connection, creating it if needed."""
        conn = getattr(self._local, "connection", None)
        if conn is None:
            conn = sqlite3.connect(
                str(self._db_path),
                check_same_thread=False,
                detect_types=sqlite3.PARSE_DECLTYPES,
            )
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA foreign_keys=ON;")
            self._local.connection = conn
        return conn

    # ------------------------------------------------------------------ #
    #  Write operations                                                    #
    # ------------------------------------------------------------------ #

    def save_scan(self, result: ScanResult) -> int:
        """
        Insert or replace a scan record.

        Returns the auto-assigned row ID.
        """
        meta = result.metadata
        vt   = result.vt_report

        row = {
            "file_path":    result.file_path,
            "filename":     result.filename,
            "status":       result.status.value if isinstance(result.status, ScanStatus) else result.status,
            "threat_level": result.threat_level.value if isinstance(result.threat_level, ThreatLevel) else result.threat_level,
            "risk_score":   result.risk_score,
            "error_message": result.error_message,
            "scanned_at":   result.scanned_at.isoformat(),
            # FileMetadata
            "sha256":       meta.sha256       if meta else None,
            "md5":          meta.md5          if meta else None,
            "size_bytes":   meta.size_bytes   if meta else None,
            "extension":    meta.extension    if meta else None,
            "mime_type":    meta.mime_type    if meta else None,
            "entropy":      meta.entropy      if meta else None,
            "strings_json": json.dumps(meta.strings[:100] if meta else []),  # cap at 100
            "patterns_json": json.dumps(meta.suspicious_patterns if meta else []),
            "yara_json":    json.dumps(meta.yara_matches if meta else []),
            # VTReport
            "vt_malicious":  vt.malicious   if vt else None,
            "vt_suspicious": vt.suspicious  if vt else None,
            "vt_undetected": vt.undetected  if vt else None,
            "vt_harmless":   vt.harmless    if vt else None,
            "vt_timeout":    vt.timeout     if vt else None,
            "vt_reputation": vt.reputation  if vt else None,
            "vt_name":       vt.meaningful_name if vt else None,
            "vt_last_date":  vt.last_analysis_date.isoformat() if (vt and vt.last_analysis_date) else None,
            "vt_uploaded":   int(vt.uploaded) if vt else 0,
            "vt_analysis_id": vt.analysis_id if vt else None,
            "vt_engines_json": json.dumps(
                [
                    {
                        "engine_name": e.engine_name,
                        "category":    e.category,
                        "result":      e.result,
                        "version":     e.engine_version,
                        "update":      e.update,
                    }
                    for e in vt.engine_results
                ]
                if vt else []
            ),
        }

        conn = self._conn()
        if result.id is not None:
            # Update existing row
            sets = ", ".join(f"{k}=:{k}" for k in row)
            row["_id"] = result.id
            conn.execute(f"UPDATE scans SET {sets} WHERE id=:_id", row)
        else:
            cols = ", ".join(row.keys())
            placeholders = ", ".join(f":{k}" for k in row)
            cur = conn.execute(
                f"INSERT INTO scans ({cols}) VALUES ({placeholders})", row
            )
            result.id = cur.lastrowid

        # Update hash cache
        if meta and meta.sha256:
            conn.execute(
                """
                INSERT INTO hash_cache (sha256, threat_level, last_seen)
                VALUES (:sha256, :tl, :ts)
                ON CONFLICT(sha256) DO UPDATE SET threat_level=:tl, last_seen=:ts
                """,
                {
                    "sha256": meta.sha256,
                    "tl": result.threat_level.value if isinstance(result.threat_level, ThreatLevel) else result.threat_level,
                    "ts": datetime.utcnow().isoformat(),
                },
            )

        conn.commit()
        return result.id  # type: ignore[return-value]

    # ------------------------------------------------------------------ #
    #  Read operations                                                     #
    # ------------------------------------------------------------------ #

    def get_scan_by_hash(self, sha256: str) -> Optional[ScanResult]:
        """Look up the most recent scan record by SHA-256."""
        conn = self._conn()
        cur = conn.execute(
            "SELECT * FROM scans WHERE sha256=? ORDER BY scanned_at DESC LIMIT 1",
            (sha256,),
        )
        row = cur.fetchone()
        if row is None:
            return None
        return self._row_to_scan_result(row)

    def get_recent_scans(self, limit: int = 100) -> list[ScanResult]:
        """Return the most recent *limit* scan records."""
        conn = self._conn()
        cur = conn.execute(
            "SELECT * FROM scans ORDER BY scanned_at DESC LIMIT ?", (limit,)
        )
        return [self._row_to_scan_result(r) for r in cur.fetchall()]

    def get_stats(self) -> dict[str, int]:
        """
        Return aggregate counters for the dashboard.

        Returns
        -------
        dict with keys: total, clean, suspicious, malicious, errors
        """
        conn = self._conn()
        cur = conn.execute("""
            SELECT
                COUNT(*) AS total,
                SUM(threat_level='clean')      AS clean,
                SUM(threat_level='suspicious') AS suspicious,
                SUM(threat_level='malicious')  AS malicious,
                SUM(status='error')            AS errors
            FROM scans
        """)
        row = cur.fetchone()
        if row is None:
            return {"total": 0, "clean": 0, "suspicious": 0, "malicious": 0, "errors": 0}
        return {
            "total":      row["total"] or 0,
            "clean":      row["clean"] or 0,
            "suspicious": row["suspicious"] or 0,
            "malicious":  row["malicious"] or 0,
            "errors":     row["errors"] or 0,
        }

    def search_scans(self, query: str, limit: int = 200) -> list[ScanResult]:
        """Full-text search on filename, sha256, and detected patterns."""
        conn = self._conn()
        q = f"%{query}%"
        cur = conn.execute(
            """
            SELECT * FROM scans
            WHERE filename LIKE ? OR sha256 LIKE ? OR patterns_json LIKE ?
            ORDER BY scanned_at DESC LIMIT ?
            """,
            (q, q, q, limit),
        )
        return [self._row_to_scan_result(r) for r in cur.fetchall()]

    def clear_history(self) -> None:
        """Delete all scan records (irreversible)."""
        conn = self._conn()
        conn.execute("DELETE FROM scans")
        conn.execute("DELETE FROM hash_cache")
        conn.commit()
        log.info("Scan history cleared.")

    # ------------------------------------------------------------------ #
    #  Deserialisation                                                     #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _row_to_scan_result(row: sqlite3.Row) -> ScanResult:
        """Reconstruct a ScanResult from a DB row."""
        d = dict(row)

        # Reconstruct FileMetadata if we have hash data
        meta: Optional[FileMetadata] = None
        if d.get("sha256"):
            from pathlib import PurePosixPath
            meta = FileMetadata(path=Path(d.get("file_path", "")))
            meta.sha256 = d.get("sha256", "")
            meta.md5    = d.get("md5", "")
            meta.size_bytes = d.get("size_bytes") or 0
            meta.extension  = d.get("extension", "")
            meta.mime_type  = d.get("mime_type", "")
            meta.entropy    = d.get("entropy") or 0.0
            try:
                meta.strings = json.loads(d.get("strings_json") or "[]")
            except (json.JSONDecodeError, TypeError):
                meta.strings = []
            try:
                meta.suspicious_patterns = json.loads(d.get("patterns_json") or "[]")
            except (json.JSONDecodeError, TypeError):
                meta.suspicious_patterns = []
            try:
                meta.yara_matches = json.loads(d.get("yara_json") or "[]")
            except (json.JSONDecodeError, TypeError):
                meta.yara_matches = []

        # Reconstruct VTReport if we have VT data
        vt: Optional[VTReport] = None
        if d.get("vt_malicious") is not None:
            vt = VTReport()
            vt.sha256       = d.get("sha256", "")
            vt.malicious    = d.get("vt_malicious", 0) or 0
            vt.suspicious   = d.get("vt_suspicious", 0) or 0
            vt.undetected   = d.get("vt_undetected", 0) or 0
            vt.harmless     = d.get("vt_harmless", 0) or 0
            vt.timeout      = d.get("vt_timeout", 0) or 0
            vt.reputation   = d.get("vt_reputation", 0) or 0
            vt.meaningful_name = d.get("vt_name") or ""
            vt.uploaded     = bool(d.get("vt_uploaded"))
            vt.analysis_id  = d.get("vt_analysis_id") or ""
            if d.get("vt_last_date"):
                try:
                    vt.last_analysis_date = datetime.fromisoformat(d["vt_last_date"])
                except (ValueError, TypeError):
                    pass

            try:
                engines_raw = json.loads(d.get("vt_engines_json") or "[]")
                vt.engine_results = [
                    EngineResult(
                        engine_name=e.get("engine_name", ""),
                        category=e.get("category", "undetected"),
                        result=e.get("result"),
                        engine_version=e.get("version", ""),
                        update=e.get("update", ""),
                    )
                    for e in engines_raw
                ]
            except (json.JSONDecodeError, TypeError, AttributeError):
                vt.engine_results = []

        # Parse status / threat_level safely
        try:
            status = ScanStatus(d.get("status", "complete"))
        except ValueError:
            status = ScanStatus.COMPLETE
        try:
            threat = ThreatLevel(d.get("threat_level", "unknown"))
        except ValueError:
            threat = ThreatLevel.UNKNOWN

        scan = ScanResult(
            id=d.get("id"),
            file_path=d.get("file_path", ""),
            filename=d.get("filename", ""),
            status=status,
            threat_level=threat,
            risk_score=d.get("risk_score", 0) or 0,
            error_message=d.get("error_message", "") or "",
            metadata=meta,
            vt_report=vt,
        )
        try:
            scan.scanned_at = datetime.fromisoformat(d.get("scanned_at", ""))
        except (ValueError, TypeError):
            scan.scanned_at = datetime.utcnow()

        return scan
