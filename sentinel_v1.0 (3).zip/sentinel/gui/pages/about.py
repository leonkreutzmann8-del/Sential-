"""
gui/pages/about.py
==================
Über-Seite mit Versionsinformationen und Update-Prüfung.

Prüft ob eine neuere Version auf GitHub verfügbar ist.
"""

from __future__ import annotations

import logging
import threading
from datetime import datetime

import requests
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from gui.styles import COLORS

log = logging.getLogger("sentinel.gui.about")

# ── Versions-Konstanten ──────────────────────────────────────────────────────
CURRENT_VERSION = "1.0.0"

# GitHub API URL — passe das auf dein eigenes Repo an falls du eines hast
# Nutzt die öffentliche Sentinel-Demo URL als Fallback
GITHUB_RELEASES_URL = "https://api.github.com/repos/leonkreutzmann8-del/Sential-/releases/latest"

# Changelog der aktuellen Version
CHANGELOG = [
    ("1.0.0", "2025-05-16", [
        "Erstveröffentlichung",
        "Downloads-Ordner Überwachung mit watchdog",
        "VirusTotal API Integration (Hash-Lookup + Upload)",
        "Lokale Dateianalyse: SHA-256, MD5, Entropy, Strings",
        "YARA-Regelunterstützung",
        "Dark-Mode GUI (Windows Defender-Stil)",
        "SQLite Datenbank für Scan-History",
        "PDF Report Export",
        "Quarantäne-Funktion",
        "Datei löschen aus History",
    ]),
]


class _ChangelogEntry(QFrame):
    """Eine Version im Changelog."""

    def __init__(self, version: str, date: str, changes: list[str], is_current: bool = False) -> None:
        super().__init__()
        border_color = COLORS["accent"] if is_current else COLORS["border"]
        self.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['bg_card']};
                border: 1px solid {border_color};
                border-radius: 8px;
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(6)

        # Header
        header = QHBoxLayout()
        version_lbl = QLabel(f"v{version}")
        version_lbl.setStyleSheet(f"""
            font-size: 15px;
            font-weight: 700;
            color: {'#00B4D8' if is_current else COLORS['text_primary']};
        """)
        header.addWidget(version_lbl)

        if is_current:
            current_badge = QLabel("  AKTUELL  ")
            current_badge.setStyleSheet(f"""
                font-size: 10px;
                font-weight: 700;
                color: {COLORS['success']};
                background-color: {COLORS['bg_surface']};
                border: 1px solid {COLORS['success']};
                border-radius: 4px;
                padding: 1px 6px;
            """)
            header.addWidget(current_badge)

        header.addStretch()
        date_lbl = QLabel(date)
        date_lbl.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 11px;")
        header.addWidget(date_lbl)
        layout.addLayout(header)

        # Änderungen
        for change in changes:
            row = QHBoxLayout()
            dot = QLabel("•")
            dot.setFixedWidth(14)
            dot.setStyleSheet(f"color: {COLORS['accent_cyan']};")
            row.addWidget(dot)
            lbl = QLabel(change)
            lbl.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 12px;")
            row.addWidget(lbl, stretch=1)
            layout.addLayout(row)


class AboutPage(QWidget):
    """
    Über-Seite mit:
    - Versionsnummer
    - Update-Prüfung (GitHub)
    - Changelog
    - Systeminformationen
    """

    def __init__(self) -> None:
        super().__init__()
        self._update_status = "unchecked"  # unchecked | checking | up_to_date | update_available | error
        self._latest_version = ""
        self._setup_ui()

    # ------------------------------------------------------------------ #
    #  UI Construction                                                     #
    # ------------------------------------------------------------------ #

    def _setup_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(16)

        # Titel
        title = QLabel("Über Sentinel")
        title.setStyleSheet(f"font-size: 20px; font-weight: 700; color: {COLORS['text_primary']};")
        layout.addWidget(title)

        # ── Versions-Card ──
        version_card = QFrame()
        version_card.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['bg_card']};
                border: 1px solid {COLORS['border']};
                border-radius: 10px;
            }}
        """)
        vc_layout = QHBoxLayout(version_card)
        vc_layout.setContentsMargins(20, 16, 20, 16)

        # Links: Logo + Version
        left = QVBoxLayout()
        logo = QLabel("🛡 SENTINEL")
        logo.setStyleSheet(f"""
            font-size: 22px;
            font-weight: 800;
            color: {COLORS['accent_cyan']};
            letter-spacing: 2px;
        """)
        left.addWidget(logo)

        self._version_lbl = QLabel(f"Version {CURRENT_VERSION}")
        self._version_lbl.setStyleSheet(f"font-size: 13px; color: {COLORS['text_secondary']};")
        left.addWidget(self._version_lbl)

        sub = QLabel("Security Monitor für Windows")
        sub.setStyleSheet(f"font-size: 11px; color: {COLORS['text_muted']};")
        left.addWidget(sub)
        vc_layout.addLayout(left, stretch=1)

        # Rechts: Update-Bereich
        right = QVBoxLayout()
        right.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        right.setSpacing(8)

        self._update_status_lbl = QLabel("Update-Status unbekannt")
        self._update_status_lbl.setAlignment(Qt.AlignRight)
        self._update_status_lbl.setStyleSheet(f"font-size: 12px; color: {COLORS['text_muted']};")
        right.addWidget(self._update_status_lbl)

        self._update_progress = QProgressBar()
        self._update_progress.setRange(0, 0)  # Indeterminate
        self._update_progress.setFixedHeight(4)
        self._update_progress.setFixedWidth(200)
        self._update_progress.setVisible(False)
        self._update_progress.setStyleSheet(f"""
            QProgressBar {{
                background-color: {COLORS['bg_surface']};
                border: none; border-radius: 2px;
            }}
            QProgressBar::chunk {{
                background-color: {COLORS['accent']};
                border-radius: 2px;
            }}
        """)
        right.addWidget(self._update_progress)

        self._check_btn = QPushButton("🔍  Auf Updates prüfen")
        self._check_btn.setFixedHeight(34)
        self._check_btn.setObjectName("btn_primary")
        self._check_btn.clicked.connect(self._check_for_updates)
        right.addWidget(self._check_btn)

        self._download_btn = QPushButton("⬇  Update herunterladen")
        self._download_btn.setFixedHeight(34)
        self._download_btn.setVisible(False)
        self._download_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['success']};
                color: white;
                border: none;
                border-radius: 6px;
                padding: 0 16px;
                font-weight: 600;
            }}
            QPushButton:hover {{ background-color: #00E676; }}
        """)
        self._download_btn.clicked.connect(self._open_download)
        right.addWidget(self._download_btn)

        vc_layout.addLayout(right)
        layout.addWidget(version_card)

        # ── System-Info ──
        sysinfo_card = QFrame()
        sysinfo_card.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['bg_card']};
                border: 1px solid {COLORS['border']};
                border-radius: 10px;
            }}
        """)
        si_layout = QVBoxLayout(sysinfo_card)
        si_layout.setContentsMargins(16, 12, 16, 12)
        si_layout.setSpacing(6)

        si_title = QLabel("SYSTEMINFORMATION")
        si_title.setStyleSheet(f"font-size: 10px; font-weight: 700; color: {COLORS['text_muted']}; letter-spacing: 1.5px;")
        si_layout.addWidget(si_title)
        si_layout.addSpacing(4)

        # Sammle Systeminfos
        import sys, platform
        infos = [
            ("Python",         sys.version.split()[0]),
            ("Plattform",      platform.system() + " " + platform.release()),
            ("Architektur",    platform.machine()),
            ("Windows-Build",  platform.version()),
        ]
        try:
            from PySide6 import __version__ as pyside_ver
            infos.append(("PySide6", pyside_ver))
        except Exception:
            pass

        for key, val in infos:
            row = QHBoxLayout()
            k = QLabel(key + ":")
            k.setFixedWidth(120)
            k.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 12px;")
            v = QLabel(val)
            v.setStyleSheet(f"color: {COLORS['text_primary']}; font-size: 12px;")
            row.addWidget(k)
            row.addWidget(v, stretch=1)
            si_layout.addLayout(row)

        layout.addWidget(sysinfo_card)

        # ── Changelog ──
        changelog_title = QLabel("CHANGELOG")
        changelog_title.setStyleSheet(f"""
            font-size: 10px;
            font-weight: 700;
            color: {COLORS['text_muted']};
            letter-spacing: 1.5px;
        """)
        layout.addWidget(changelog_title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        inner = QWidget()
        inner.setStyleSheet("background: transparent;")
        inner_layout = QVBoxLayout(inner)
        inner_layout.setSpacing(10)
        inner_layout.setContentsMargins(0, 0, 0, 0)

        for i, (version, date, changes) in enumerate(CHANGELOG):
            entry = _ChangelogEntry(
                version, date, changes,
                is_current=(version == CURRENT_VERSION)
            )
            inner_layout.addWidget(entry)

        inner_layout.addStretch()
        scroll.setWidget(inner)
        layout.addWidget(scroll, stretch=1)

        # ── Footer ──
        footer = QLabel(
            "Sentinel ist ein defensives, bildungsorientiertes Tool. "
            "Es löscht, verändert oder führt niemals Dateien aus."
        )
        footer.setStyleSheet(f"""
            color: {COLORS['text_muted']};
            font-size: 11px;
            border-top: 1px solid {COLORS['border']};
            padding-top: 10px;
        """)
        footer.setWordWrap(True)
        layout.addWidget(footer)

    # ------------------------------------------------------------------ #
    #  Update-Prüfung                                                      #
    # ------------------------------------------------------------------ #

    def _check_for_updates(self) -> None:
        """Prüft im Hintergrund ob eine neuere Version verfügbar ist."""
        self._check_btn.setEnabled(False)
        self._check_btn.setText("Prüfe...")
        self._update_progress.setVisible(True)
        self._update_status_lbl.setText("Verbinde mit GitHub...")
        self._update_status_lbl.setStyleSheet(f"font-size: 12px; color: {COLORS['text_muted']};")

        # Hintergrund-Thread damit die GUI nicht einfriert
        thread = threading.Thread(target=self._fetch_latest_version, daemon=True)
        thread.start()

    def _fetch_latest_version(self) -> None:
        """Läuft im Hintergrund-Thread."""
        try:
            resp = requests.get(
                GITHUB_RELEASES_URL,
                timeout=8,
                headers={"User-Agent": f"Sentinel/{CURRENT_VERSION}"},
            )
            if resp.status_code == 200:
                data = resp.json()
                tag = data.get("tag_name", "").lstrip("v")
                self._latest_version = tag
                # GUI-Update muss im Main-Thread passieren → QTimer
                QTimer.singleShot(0, self._on_update_result_ok)
            elif resp.status_code == 404:
                # Kein GitHub-Repo konfiguriert — zeige "Aktuell"
                QTimer.singleShot(0, self._on_no_repo)
            else:
                QTimer.singleShot(0, self._on_update_error)
        except requests.exceptions.ConnectionError:
            QTimer.singleShot(0, self._on_no_internet)
        except Exception as exc:
            log.warning("Update check failed: %s", exc)
            QTimer.singleShot(0, self._on_update_error)

    def _on_update_result_ok(self) -> None:
        self._update_progress.setVisible(False)
        self._check_btn.setEnabled(True)
        self._check_btn.setText("🔍  Auf Updates prüfen")

        if not self._latest_version:
            self._on_no_repo()
            return

        if self._is_newer(self._latest_version, CURRENT_VERSION):
            # Update verfügbar
            self._update_status_lbl.setText(
                f"🆕  Version {self._latest_version} verfügbar!"
            )
            self._update_status_lbl.setStyleSheet(
                f"font-size: 12px; color: {COLORS['success']}; font-weight: 700;"
            )
            self._download_btn.setVisible(True)
            self._download_btn.setText(f"⬇  v{self._latest_version} herunterladen")
        else:
            # Aktuell
            self._update_status_lbl.setText(
                f"✅  Sentinel ist aktuell (v{CURRENT_VERSION})"
            )
            self._update_status_lbl.setStyleSheet(
                f"font-size: 12px; color: {COLORS['success']};"
            )
            self._download_btn.setVisible(False)

    def _on_no_repo(self) -> None:
        self._update_progress.setVisible(False)
        self._check_btn.setEnabled(True)
        self._check_btn.setText("🔍  Auf Updates prüfen")
        self._update_status_lbl.setText(f"✅  Version {CURRENT_VERSION} — aktuell")
        self._update_status_lbl.setStyleSheet(
            f"font-size: 12px; color: {COLORS['success']};"
        )

    def _on_no_internet(self) -> None:
        self._update_progress.setVisible(False)
        self._check_btn.setEnabled(True)
        self._check_btn.setText("🔍  Auf Updates prüfen")
        self._update_status_lbl.setText("⚠️  Keine Internetverbindung")
        self._update_status_lbl.setStyleSheet(
            f"font-size: 12px; color: {COLORS['warning']};"
        )

    def _on_update_error(self) -> None:
        self._update_progress.setVisible(False)
        self._check_btn.setEnabled(True)
        self._check_btn.setText("🔍  Auf Updates prüfen")
        self._update_status_lbl.setText("❌  Prüfung fehlgeschlagen")
        self._update_status_lbl.setStyleSheet(
            f"font-size: 12px; color: {COLORS['danger']};"
        )

    def _open_download(self) -> None:
        """Öffnet die GitHub Releases Seite im Browser."""
        import webbrowser
        webbrowser.open("https://github.com/sentinel-security/sentinel/releases")

    @staticmethod
    def _is_newer(latest: str, current: str) -> bool:
        """Vergleicht zwei Versionstrings (major.minor.patch)."""
        try:
            def parse(v: str) -> tuple:
                return tuple(int(x) for x in v.strip().split("."))
            return parse(latest) > parse(current)
        except (ValueError, AttributeError):
            return False
