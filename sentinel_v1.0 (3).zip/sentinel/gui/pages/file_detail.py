"""
gui/pages/file_detail.py
========================
Detailed view of a single scan result: hashes, VT report,
AV engine table, entropy, patterns, and risk score.
"""

from __future__ import annotations

import logging
from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)
from PySide6.QtGui import QColor

from core.models import EngineResult, ScanResult, ThreatLevel, VTReport
from gui.styles import COLORS

log = logging.getLogger("sentinel.gui.file_detail")

_THREAT_COLORS = {
    ThreatLevel.MALICIOUS:  COLORS["danger"],
    ThreatLevel.SUSPICIOUS: COLORS["suspicious"],
    ThreatLevel.CLEAN:      COLORS["success"],
    ThreatLevel.UNKNOWN:    COLORS["text_muted"],
}

_CATEGORY_COLORS = {
    "malicious":  COLORS["danger"],
    "suspicious": COLORS["suspicious"],
    "undetected": COLORS["text_muted"],
    "harmless":   COLORS["success"],
    "timeout":    COLORS["text_muted"],
}


class _InfoRow(QHBoxLayout):
    """Key-value row for the metadata section."""

    def __init__(self, key: str, value: str = "—", monospace: bool = False) -> None:
        super().__init__()
        key_lbl = QLabel(key + ":")
        key_lbl.setFixedWidth(130)
        key_lbl.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 12px;")
        self.addWidget(key_lbl)

        self._val = QLabel(value)
        self._val.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self._val.setWordWrap(True)
        font_family = '"Cascadia Code", "JetBrains Mono", Consolas, monospace' if monospace else "inherit"
        self._val.setStyleSheet(
            f"color: {COLORS['text_primary']}; font-size: 12px; font-family: {font_family};"
        )
        self.addWidget(self._val, stretch=1)

    def set_value(self, value: str) -> None:
        self._val.setText(value)

    def set_color(self, color: str) -> None:
        self._val.setStyleSheet(
            f"color: {color}; font-size: 12px; font-weight: 700;"
        )


class FileDetailPage(QWidget):
    """
    Full-screen detail view for one scan result.

    Loads a ScanResult via :meth:`load_result`.
    """

    def __init__(self) -> None:
        super().__init__()
        self._result: Optional[ScanResult] = None
        self._setup_ui()

    # ------------------------------------------------------------------ #
    #  UI Construction                                                     #
    # ------------------------------------------------------------------ #

    def _setup_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 20)
        outer.setSpacing(0)

        # Header with back button
        header = QHBoxLayout()
        self._back_btn = QPushButton("← Back")
        self._back_btn.setFixedWidth(80)
        self._back_btn.setFixedHeight(30)
        header.addWidget(self._back_btn)
        header.addSpacing(12)

        self._title_lbl = QLabel("File Detail")
        self._title_lbl.setStyleSheet(
            f"font-size: 20px; font-weight: 700; color: {COLORS['text_primary']};"
        )
        header.addWidget(self._title_lbl)
        header.addStretch()

        self._threat_badge = QLabel("UNKNOWN")
        self._threat_badge.setAlignment(Qt.AlignCenter)
        self._threat_badge.setFixedHeight(32)
        self._threat_badge.setMinimumWidth(120)
        self._threat_badge.setStyleSheet(f"""
            font-size: 13px; font-weight: 800; letter-spacing: 1.5px;
            color: {COLORS['text_muted']}; border: 2px solid {COLORS['text_muted']};
            border-radius: 6px; padding: 0 12px;
        """)
        header.addWidget(self._threat_badge)
        outer.addLayout(header)
        outer.addSpacing(14)

        # Scrollable main area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        inner = QWidget()
        inner_layout = QVBoxLayout(inner)
        inner_layout.setSpacing(16)
        inner_layout.setContentsMargins(0, 0, 0, 0)
        scroll.setWidget(inner)
        outer.addWidget(scroll, stretch=1)

        # ── Risk score bar ──
        risk_frame = QFrame()
        risk_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['bg_card']};
                border: 1px solid {COLORS['border']};
                border-radius: 10px;
            }}
        """)
        risk_layout = QHBoxLayout(risk_frame)
        risk_layout.setContentsMargins(16, 12, 16, 12)

        risk_left = QVBoxLayout()
        risk_lbl = QLabel("RISK SCORE")
        risk_lbl.setStyleSheet(f"font-size: 10px; color: {COLORS['text_muted']}; letter-spacing: 1px;")
        risk_left.addWidget(risk_lbl)
        self._risk_score_lbl = QLabel("0")
        self._risk_score_lbl.setStyleSheet(f"font-size: 40px; font-weight: 800; color: {COLORS['text_primary']};")
        risk_left.addWidget(self._risk_score_lbl)
        risk_layout.addLayout(risk_left)
        risk_layout.addSpacing(20)

        self._risk_bar = QProgressBar()
        self._risk_bar.setRange(0, 100)
        self._risk_bar.setValue(0)
        self._risk_bar.setFixedHeight(20)
        self._risk_bar.setTextVisible(False)
        self._risk_bar.setStyleSheet(f"""
            QProgressBar {{
                background-color: {COLORS['bg_surface']};
                border: none; border-radius: 10px;
            }}
            QProgressBar::chunk {{
                background-color: {COLORS['success']};
                border-radius: 10px;
            }}
        """)
        risk_layout.addWidget(self._risk_bar, stretch=1)
        inner_layout.addWidget(risk_frame)

        # ── Detection summary (VT) ──
        self._detection_frame = self._build_detection_section()
        inner_layout.addWidget(self._detection_frame)

        # ── Two-column layout: metadata left, patterns right ──
        two_col = QHBoxLayout()
        two_col.setSpacing(16)

        self._meta_group = self._build_metadata_section()
        two_col.addWidget(self._meta_group, stretch=1)

        self._patterns_group = self._build_patterns_section()
        two_col.addWidget(self._patterns_group, stretch=1)

        inner_layout.addLayout(two_col)

        # ── AV Engine results table ──
        self._engine_group = self._build_engine_table()
        inner_layout.addWidget(self._engine_group)

        # ── Extracted strings ──
        self._strings_group = self._build_strings_section()
        inner_layout.addWidget(self._strings_group)

        inner_layout.addStretch()

    def _build_detection_section(self) -> QFrame:
        frame = QFrame()
        frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['bg_card']};
                border: 1px solid {COLORS['border']};
                border-radius: 10px;
            }}
        """)
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(16, 12, 16, 12)

        hdr = QLabel("VIRUSTOTAL ANALYSIS")
        hdr.setStyleSheet(
            f"font-size: 10px; color: {COLORS['text_muted']}; "
            f"font-weight: 700; letter-spacing: 1.5px;"
        )
        layout.addWidget(hdr)
        layout.addSpacing(8)

        self._detection_summary = QLabel("No VirusTotal data available")
        self._detection_summary.setStyleSheet(
            f"font-size: 17px; font-weight: 700; color: {COLORS['text_primary']};"
        )
        layout.addWidget(self._detection_summary)

        # Detection progress bars row
        bars_row = QHBoxLayout()
        bars_row.setSpacing(16)

        self._det_bars: dict[str, tuple[QProgressBar, QLabel]] = {}
        for key, label, color in [
            ("malicious",  "Malicious",  COLORS["danger"]),
            ("suspicious", "Suspicious", COLORS["suspicious"]),
            ("undetected", "Undetected", COLORS["text_muted"]),
            ("harmless",   "Harmless",   COLORS["success"]),
        ]:
            col = QVBoxLayout()
            pb = QProgressBar()
            pb.setRange(0, 100)
            pb.setValue(0)
            pb.setTextVisible(False)
            pb.setFixedHeight(8)
            pb.setStyleSheet(f"""
                QProgressBar {{
                    background-color: {COLORS['bg_surface']};
                    border: none; border-radius: 4px;
                }}
                QProgressBar::chunk {{
                    background-color: {color}; border-radius: 4px;
                }}
            """)
            val_lbl = QLabel("0")
            val_lbl.setStyleSheet(f"font-size: 18px; font-weight: 700; color: {color};")
            cat_lbl = QLabel(label)
            cat_lbl.setStyleSheet(f"font-size: 10px; color: {COLORS['text_muted']}; letter-spacing: 0.5px;")
            col.addWidget(val_lbl)
            col.addWidget(cat_lbl)
            col.addWidget(pb)
            bars_row.addLayout(col)
            self._det_bars[key] = (pb, val_lbl)

        layout.addLayout(bars_row)
        return frame

    def _build_metadata_section(self) -> QGroupBox:
        group = QGroupBox("File Metadata")
        layout = QVBoxLayout(group)
        layout.setSpacing(6)

        self._row_filename  = _InfoRow("Filename")
        self._row_path      = _InfoRow("Full Path")
        self._row_size      = _InfoRow("Size")
        self._row_sha256    = _InfoRow("SHA-256",   monospace=True)
        self._row_md5       = _InfoRow("MD5",        monospace=True)
        self._row_mime      = _InfoRow("MIME Type")
        self._row_entropy   = _InfoRow("Entropy")
        self._row_scanned   = _InfoRow("Scanned At")

        for row in [self._row_filename, self._row_path, self._row_size,
                    self._row_sha256, self._row_md5, self._row_mime,
                    self._row_entropy, self._row_scanned]:
            layout.addLayout(row)

        return group

    def _build_patterns_section(self) -> QGroupBox:
        group = QGroupBox("Suspicious Patterns & YARA Matches")
        layout = QVBoxLayout(group)

        self._patterns_text = QTextEdit()
        self._patterns_text.setReadOnly(True)
        self._patterns_text.setFixedHeight(180)
        self._patterns_text.setPlaceholderText("No suspicious patterns detected.")
        layout.addWidget(self._patterns_text)

        return group

    def _build_engine_table(self) -> QGroupBox:
        group = QGroupBox("Antivirus Engine Results")
        layout = QVBoxLayout(group)

        self._engine_table = QTableWidget()
        self._engine_table.setColumnCount(4)
        self._engine_table.setHorizontalHeaderLabels(
            ["Engine", "Category", "Detection Name", "Version"]
        )
        self._engine_table.setAlternatingRowColors(True)
        self._engine_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._engine_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._engine_table.verticalHeader().setVisible(False)
        self._engine_table.setShowGrid(False)
        self._engine_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self._engine_table.setColumnWidth(0, 150)
        self._engine_table.setColumnWidth(1, 100)
        self._engine_table.setColumnWidth(3, 100)
        self._engine_table.setFixedHeight(280)
        layout.addWidget(self._engine_table)

        return group

    def _build_strings_section(self) -> QGroupBox:
        group = QGroupBox("Extracted Strings (first 100)")
        layout = QVBoxLayout(group)

        self._strings_text = QTextEdit()
        self._strings_text.setReadOnly(True)
        self._strings_text.setFixedHeight(160)
        self._strings_text.setPlaceholderText("No strings extracted.")
        layout.addWidget(self._strings_text)

        return group

    # ------------------------------------------------------------------ #
    #  Public API                                                          #
    # ------------------------------------------------------------------ #

    def load_result(self, result: ScanResult) -> None:
        """Populate the view with *result*."""
        self._result = result
        self._populate(result)

    # ------------------------------------------------------------------ #
    #  Population                                                          #
    # ------------------------------------------------------------------ #

    def _populate(self, result: ScanResult) -> None:
        meta = result.metadata
        vt   = result.vt_report
        level = result.threat_level
        color = _THREAT_COLORS.get(level, COLORS["text_muted"])

        # Title
        self._title_lbl.setText(result.filename)

        # Threat badge
        self._threat_badge.setText(f"  {level.value.upper()}  ")
        self._threat_badge.setStyleSheet(f"""
            font-size: 13px; font-weight: 800; letter-spacing: 1.5px;
            color: {color}; border: 2px solid {color};
            border-radius: 6px; padding: 0 12px;
        """)

        # Risk score
        self._risk_score_lbl.setText(str(result.risk_score))
        self._risk_bar.setValue(result.risk_score)
        bar_color = (
            COLORS["danger"]     if result.risk_score >= 75 else
            COLORS["warning"]    if result.risk_score >= 40 else
            COLORS["suspicious"] if result.risk_score >= 10 else
            COLORS["success"]
        )
        self._risk_bar.setStyleSheet(f"""
            QProgressBar {{
                background-color: {COLORS['bg_surface']};
                border: none; border-radius: 10px;
            }}
            QProgressBar::chunk {{
                background-color: {bar_color}; border-radius: 10px;
            }}
        """)
        self._risk_score_lbl.setStyleSheet(
            f"font-size: 40px; font-weight: 800; color: {bar_color};"
        )

        # VT detection section
        self._populate_vt(vt)

        # Metadata
        if meta:
            self._row_filename.set_value(meta.filename)
            self._row_path.set_value(str(meta.path))
            self._row_size.set_value(f"{meta.size_bytes:,} bytes")
            self._row_sha256.set_value(meta.sha256 or "—")
            self._row_md5.set_value(meta.md5 or "—")
            self._row_mime.set_value(meta.mime_type or "—")
            entropy_color = (
                COLORS["danger"]     if meta.entropy > 7.5 else
                COLORS["warning"]    if meta.entropy > 7.0 else
                COLORS["text_primary"]
            )
            self._row_entropy.set_value(f"{meta.entropy:.4f} / 8.0")
            self._row_entropy.set_color(entropy_color)
        else:
            for row in [self._row_filename, self._row_path, self._row_size,
                        self._row_sha256, self._row_md5, self._row_mime, self._row_entropy]:
                row.set_value("—")

        self._row_scanned.set_value(
            result.scanned_at.strftime("%Y-%m-%d %H:%M:%S UTC") if result.scanned_at else "—"
        )

        # Patterns & YARA
        lines = []
        if meta and meta.suspicious_patterns:
            lines.append("── Suspicious Patterns ──")
            for p in meta.suspicious_patterns:
                lines.append(f"  ⚠  {p}")
        if meta and meta.yara_matches:
            lines.append("")
            lines.append("── YARA Matches ──")
            for y in meta.yara_matches:
                lines.append(f"  🎯  {y}")
        if not lines:
            lines = ["No suspicious patterns or YARA matches detected."]
        self._patterns_text.setPlainText("\n".join(lines))

        # Engine table
        self._populate_engine_table(vt.engine_results if vt else [])

        # Strings
        if meta and meta.strings:
            self._strings_text.setPlainText("\n".join(meta.strings[:100]))
        else:
            self._strings_text.setPlainText("")

    def _populate_vt(self, vt: Optional[VTReport]) -> None:
        if not vt or vt.total_engines == 0:
            self._detection_summary.setText("No VirusTotal data available")
            self._detection_summary.setStyleSheet(
                f"font-size: 17px; font-weight: 700; color: {COLORS['text_muted']};"
            )
            for key, (pb, val_lbl) in self._det_bars.items():
                pb.setValue(0)
                val_lbl.setText("0")
            return

        summary = vt.summary_label
        self._detection_summary.setText(summary)
        tl_color = _THREAT_COLORS.get(vt.threat_level, COLORS["text_muted"])
        self._detection_summary.setStyleSheet(
            f"font-size: 17px; font-weight: 700; color: {tl_color};"
        )

        total = max(vt.total_engines, 1)
        for key, (pb, val_lbl) in self._det_bars.items():
            count = getattr(vt, key, 0)
            pb.setValue(int(count / total * 100))
            val_lbl.setText(str(count))

    def _populate_engine_table(self, engines: list[EngineResult]) -> None:
        self._engine_table.setRowCount(len(engines))
        for row, eng in enumerate(engines):
            color_str = _CATEGORY_COLORS.get(eng.category, COLORS["text_muted"])
            q_color = QColor(color_str)

            name_item = QTableWidgetItem(eng.engine_name)
            name_item.setForeground(QColor(COLORS["text_primary"]))

            cat_item = QTableWidgetItem(eng.category.upper())
            cat_item.setForeground(q_color)
            cat_item.setTextAlignment(Qt.AlignCenter | Qt.AlignVCenter)

            result_item = QTableWidgetItem(eng.result or "—")
            result_item.setForeground(q_color if eng.result else QColor(COLORS["text_muted"]))

            ver_item = QTableWidgetItem(eng.engine_version or "—")
            ver_item.setForeground(QColor(COLORS["text_muted"]))

            self._engine_table.setItem(row, 0, name_item)
            self._engine_table.setItem(row, 1, cat_item)
            self._engine_table.setItem(row, 2, result_item)
            self._engine_table.setItem(row, 3, ver_item)
            self._engine_table.setRowHeight(row, 28)
