"""
gui/pages/scan_feed.py
======================
Real-time scrolling feed of scan events with animated status indicators.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Optional

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from core.models import ScanResult, ScanStatus, ThreatLevel
from gui.styles import COLORS

log = logging.getLogger("sentinel.gui.scan_feed")

# Map threat level → display config (border colour, icon, label)
_THREAT_STYLE = {
    ThreatLevel.MALICIOUS:  (COLORS["danger"],     "🚨", "MALICIOUS"),
    ThreatLevel.SUSPICIOUS: (COLORS["suspicious"], "⚠️",  "SUSPICIOUS"),
    ThreatLevel.CLEAN:      (COLORS["success"],    "✅", "CLEAN"),
    ThreatLevel.UNKNOWN:    (COLORS["text_muted"], "❓", "UNKNOWN"),
}

_STATUS_COLOR = {
    ScanStatus.QUEUED:    COLORS["text_muted"],
    ScanStatus.HASHING:   COLORS["accent_cyan"],
    ScanStatus.VT_LOOKUP: COLORS["accent"],
    ScanStatus.UPLOADING: COLORS["accent"],
    ScanStatus.POLLING:   COLORS["accent"],
    ScanStatus.COMPLETE:  COLORS["success"],
    ScanStatus.ERROR:     COLORS["danger"],
    ScanStatus.SKIPPED:   COLORS["text_muted"],
}


class FeedItem(QFrame):
    """
    Single row in the live feed.

    Can be updated in-place as the scan progresses through states.
    """

    # Emitted when the user clicks "View Details"
    view_requested = Signal(str)  # filename

    def __init__(self, filename: str) -> None:
        super().__init__()
        self._filename = filename
        self._result: Optional[ScanResult] = None
        self._setup_ui()
        self.set_scanning()

    # ------------------------------------------------------------------ #
    #  UI Construction                                                     #
    # ------------------------------------------------------------------ #

    def _setup_ui(self) -> None:
        self.setFixedHeight(64)
        self.setObjectName("feed_item")
        self.setStyleSheet(f"""
            QFrame#feed_item {{
                background-color: {COLORS['bg_card']};
                border: 1px solid {COLORS['border']};
                border-left: 4px solid {COLORS['text_muted']};
                border-radius: 6px;
                margin: 2px 0;
            }}
        """)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 8, 12, 8)
        layout.setSpacing(12)

        # Status icon
        self._icon_lbl = QLabel("⏳")
        self._icon_lbl.setFixedWidth(24)
        self._icon_lbl.setStyleSheet("font-size: 18px;")
        layout.addWidget(self._icon_lbl)

        # File info
        info_col = QVBoxLayout()
        info_col.setSpacing(2)

        self._name_lbl = QLabel(self._filename)
        self._name_lbl.setStyleSheet(f"""
            font-size: 13px;
            font-weight: 600;
            color: {COLORS['text_primary']};
        """)
        self._name_lbl.setMaximumWidth(400)
        info_col.addWidget(self._name_lbl)

        self._detail_lbl = QLabel("Queued for scanning…")
        self._detail_lbl.setStyleSheet(f"font-size: 11px; color: {COLORS['text_muted']};")
        info_col.addWidget(self._detail_lbl)

        layout.addLayout(info_col, stretch=1)

        # Threat badge
        self._threat_lbl = QLabel("SCANNING")
        self._threat_lbl.setAlignment(Qt.AlignCenter)
        self._threat_lbl.setFixedWidth(90)
        self._threat_lbl.setStyleSheet(f"""
            font-size: 10px;
            font-weight: 700;
            color: {COLORS['accent_cyan']};
            background-color: {COLORS['bg_surface']};
            border: 1px solid {COLORS['accent_cyan']};
            border-radius: 4px;
            padding: 2px 6px;
            letter-spacing: 0.5px;
        """)
        layout.addWidget(self._threat_lbl)

        # Timestamp
        self._time_lbl = QLabel(datetime.now().strftime("%H:%M:%S"))
        self._time_lbl.setStyleSheet(f"font-size: 10px; color: {COLORS['text_muted']};")
        self._time_lbl.setFixedWidth(56)
        layout.addWidget(self._time_lbl)

        # View button (hidden until complete)
        self._view_btn = QPushButton("View")
        self._view_btn.setFixedSize(60, 26)
        self._view_btn.setVisible(False)
        self._view_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                color: {COLORS['accent_cyan']};
                border: 1px solid {COLORS['accent_cyan']};
                border-radius: 4px;
                font-size: 11px;
            }}
            QPushButton:hover {{
                background-color: {COLORS['accent']};
                color: white;
                border-color: {COLORS['accent']};
            }}
        """)
        self._view_btn.clicked.connect(lambda: self.view_requested.emit(self._filename))
        layout.addWidget(self._view_btn)

    # ------------------------------------------------------------------ #
    #  State updates                                                       #
    # ------------------------------------------------------------------ #

    def set_scanning(self) -> None:
        """Show animated scanning state."""
        self._icon_lbl.setText("⏳")
        self._detail_lbl.setText("Scanning…")
        self._threat_lbl.setText("SCANNING")
        self._threat_lbl.setStyleSheet(f"""
            font-size: 10px; font-weight: 700;
            color: {COLORS['accent_cyan']};
            background-color: {COLORS['bg_surface']};
            border: 1px solid {COLORS['accent_cyan']};
            border-radius: 4px; padding: 2px 6px;
        """)

    def update_result(self, result: ScanResult) -> None:
        """Update the item with the final scan result."""
        self._result = result
        level = result.threat_level
        color, icon, label = _THREAT_STYLE.get(level, (COLORS["text_muted"], "❓", "UNKNOWN"))

        self._icon_lbl.setText(icon)
        self._time_lbl.setText(datetime.now().strftime("%H:%M:%S"))
        self._view_btn.setVisible(True)

        # Detail text
        if result.vt_report and result.vt_report.total_engines > 0:
            self._detail_lbl.setText(result.vt_report.summary_label)
        elif result.metadata:
            patterns = ", ".join(result.metadata.suspicious_patterns[:3])
            if patterns:
                self._detail_lbl.setText(f"Patterns: {patterns}")
            else:
                size = result.metadata.size_bytes
                self._detail_lbl.setText(f"{size:,} bytes • {result.metadata.mime_type}")
        elif result.status == ScanStatus.ERROR:
            self._detail_lbl.setText(f"Error: {result.error_message[:60]}")
        else:
            self._detail_lbl.setText("Analysis complete")

        # Threat badge
        self._threat_lbl.setText(label)
        self._threat_lbl.setStyleSheet(f"""
            font-size: 10px; font-weight: 700;
            color: {color};
            background-color: {COLORS['bg_surface']};
            border: 1px solid {color};
            border-radius: 4px; padding: 2px 6px;
            letter-spacing: 0.5px;
        """)

        # Left border colour
        self.setStyleSheet(f"""
            QFrame#feed_item {{
                background-color: {COLORS['bg_card']};
                border: 1px solid {COLORS['border']};
                border-left: 4px solid {color};
                border-radius: 6px;
                margin: 2px 0;
            }}
        """)


class ScanFeedPage(QWidget):
    """
    Scrollable live feed of scan events.

    Emits ``view_detail_requested`` when the user clicks "View" on an item.
    """

    view_detail_requested = Signal(object)  # ScanResult

    def __init__(self) -> None:
        super().__init__()
        self._items: dict[str, FeedItem] = {}  # filename → FeedItem
        self._results: dict[str, ScanResult] = {}
        self._setup_ui()

    # ------------------------------------------------------------------ #
    #  UI Construction                                                     #
    # ------------------------------------------------------------------ #

    def _setup_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(12)

        # Header
        header = QHBoxLayout()
        title = QLabel("Live Scan Feed")
        title.setStyleSheet(f"font-size: 20px; font-weight: 700; color: {COLORS['text_primary']};")
        header.addWidget(title)
        header.addStretch()

        self._count_lbl = QLabel("0 events")
        self._count_lbl.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 12px;")
        header.addWidget(self._count_lbl)

        clear_btn = QPushButton("Clear Feed")
        clear_btn.setFixedHeight(30)
        clear_btn.clicked.connect(self._clear_feed)
        header.addWidget(clear_btn)
        layout.addLayout(header)

        # Column headers
        col_header = QHBoxLayout()
        col_header.setContentsMargins(16, 0, 16, 0)
        for text, width in [("File", 0), ("Status", 100), ("Time", 60), ("", 60)]:
            lbl = QLabel(text.upper())
            lbl.setStyleSheet(f"""
                font-size: 10px;
                color: {COLORS['text_muted']};
                font-weight: 700;
                letter-spacing: 1px;
            """)
            if width:
                lbl.setFixedWidth(width)
            else:
                col_header.addWidget(lbl, stretch=1)
                continue
            col_header.addWidget(lbl)
        layout.addLayout(col_header)

        # Scrollable feed
        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QFrame.NoFrame)

        self._feed_widget = QWidget()
        self._feed_layout = QVBoxLayout(self._feed_widget)
        self._feed_layout.setContentsMargins(0, 0, 0, 0)
        self._feed_layout.setSpacing(4)
        self._feed_layout.addStretch()

        self._scroll.setWidget(self._feed_widget)
        layout.addWidget(self._scroll, stretch=1)

        # Empty state
        self._empty_lbl = QLabel("Waiting for new downloads…\n\nSentinel will automatically scan files added to your Downloads folder.")
        self._empty_lbl.setAlignment(Qt.AlignCenter)
        self._empty_lbl.setStyleSheet(f"""
            color: {COLORS['text_muted']};
            font-size: 13px;
            padding: 40px;
            line-height: 1.6;
        """)
        layout.addWidget(self._empty_lbl)

    # ------------------------------------------------------------------ #
    #  Public API                                                          #
    # ------------------------------------------------------------------ #

    def add_scanning_item(self, filename: str) -> None:
        """Add a new entry showing that *filename* is being scanned."""
        if filename in self._items:
            self._items[filename].set_scanning()
            return

        self._empty_lbl.setVisible(False)

        item = FeedItem(filename)
        item.view_requested.connect(self._on_view_requested)
        self._items[filename] = item

        # Insert before the trailing stretch
        count = self._feed_layout.count()
        self._feed_layout.insertWidget(count - 1, item)

        # Scroll to bottom
        QTimer.singleShot(50, self._scroll_to_bottom)
        self._update_count()

        # Limit visible items to 100
        if count > 101:
            self._trim_old_items()

    def update_item(self, result: ScanResult) -> None:
        """Update an existing item with the completed scan result."""
        self._results[result.filename] = result
        item = self._items.get(result.filename)
        if item:
            item.update_result(result)
        else:
            # Item not in feed yet — add it
            self.add_scanning_item(result.filename)
            item = self._items.get(result.filename)
            if item:
                item.update_result(result)

    # ------------------------------------------------------------------ #
    #  Internal                                                            #
    # ------------------------------------------------------------------ #

    def _on_view_requested(self, filename: str) -> None:
        result = self._results.get(filename)
        if result:
            self.view_detail_requested.emit(result)

    def _scroll_to_bottom(self) -> None:
        vsb = self._scroll.verticalScrollBar()
        vsb.setValue(vsb.maximum())

    def _update_count(self) -> None:
        n = len(self._items)
        self._count_lbl.setText(f"{n} event{'s' if n != 1 else ''}")

    def _trim_old_items(self) -> None:
        """Remove the oldest item to keep the feed manageable."""
        if self._feed_layout.count() > 1:
            item_obj = self._feed_layout.takeAt(0)
            if item_obj and item_obj.widget():
                widget = item_obj.widget()
                # Find and remove from dicts
                to_remove = [k for k, v in self._items.items() if v is widget]
                for k in to_remove:
                    self._items.pop(k, None)
                    self._results.pop(k, None)
                widget.deleteLater()

    def _clear_feed(self) -> None:
        """Clear all items from the feed."""
        for item in self._items.values():
            item.deleteLater()
        self._items.clear()
        self._results.clear()
        self._empty_lbl.setVisible(True)
        self._update_count()
