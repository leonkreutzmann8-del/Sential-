"""
gui/pages/settings.py
=====================
Settings page: API key, watch path, rate limits, and other preferences.
"""

from __future__ import annotations

import logging
from pathlib import Path

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QFileDialog,
    QFormLayout,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from core.config import Config
from gui.styles import COLORS

log = logging.getLogger("sentinel.gui.settings")


class SettingsPage(QWidget):
    """User-configurable settings panel."""

    watch_path_changed = Signal(str)

    def __init__(self, config: Config) -> None:
        super().__init__()
        self._config = config
        self._setup_ui()
        self._load_from_config()

    def _setup_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(16)

        title = QLabel("Settings")
        title.setStyleSheet(
            f"font-size: 20px; font-weight: 700; color: {COLORS['text_primary']};"
        )
        layout.addWidget(title)

        # ── VirusTotal ──
        vt_group = QGroupBox("VirusTotal API")
        vt_layout = QFormLayout(vt_group)
        vt_layout.setSpacing(10)
        vt_layout.setContentsMargins(16, 20, 16, 16)

        self._vt_key_edit = QLineEdit()
        self._vt_key_edit.setEchoMode(QLineEdit.Password)
        self._vt_key_edit.setPlaceholderText("Enter your VirusTotal API key…")

        show_btn = QPushButton("Show")
        show_btn.setFixedWidth(60)
        show_btn.setCheckable(True)
        show_btn.toggled.connect(
            lambda checked: self._vt_key_edit.setEchoMode(
                QLineEdit.Normal if checked else QLineEdit.Password
            )
        )
        key_row = QHBoxLayout()
        key_row.addWidget(self._vt_key_edit)
        key_row.addWidget(show_btn)
        vt_layout.addRow("API Key:", key_row)

        self._rate_limit_spin = QSpinBox()
        self._rate_limit_spin.setRange(1, 500)
        self._rate_limit_spin.setSuffix(" requests/min")
        vt_layout.addRow("Rate Limit:", self._rate_limit_spin)

        info = QLabel(
            "Free tier: 4 requests/min | Premium: up to 500/min\n"
            "<a href='https://www.virustotal.com/gui/sign-in' "
            "style='color:#00B4D8'>Get a free API key →</a>"
        )
        info.setOpenExternalLinks(True)
        info.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 11px;")
        vt_layout.addRow("", info)
        layout.addWidget(vt_group)

        # ── Monitoring ──
        mon_group = QGroupBox("Monitoring")
        mon_layout = QFormLayout(mon_group)
        mon_layout.setSpacing(10)
        mon_layout.setContentsMargins(16, 20, 16, 16)

        path_row = QHBoxLayout()
        self._watch_path_edit = QLineEdit()
        self._watch_path_edit.setReadOnly(True)
        browse_btn = QPushButton("Browse…")
        browse_btn.setFixedWidth(80)
        browse_btn.clicked.connect(self._browse_path)
        path_row.addWidget(self._watch_path_edit)
        path_row.addWidget(browse_btn)
        mon_layout.addRow("Watch Folder:", path_row)
        layout.addWidget(mon_group)

        # ── Storage ──
        storage_group = QGroupBox("Storage")
        storage_layout = QFormLayout(storage_group)
        storage_layout.setSpacing(10)
        storage_layout.setContentsMargins(16, 20, 16, 16)

        self._db_path_lbl = QLabel()
        self._db_path_lbl.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 12px;")
        storage_layout.addRow("Database:", self._db_path_lbl)

        self._reports_lbl = QLabel()
        self._reports_lbl.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 12px;")
        storage_layout.addRow("Reports:", self._reports_lbl)

        self._quarantine_lbl = QLabel()
        self._quarantine_lbl.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 12px;")
        storage_layout.addRow("Quarantine:", self._quarantine_lbl)
        layout.addWidget(storage_group)

        # ── Save button ──
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        save_btn = QPushButton("Save Settings")
        save_btn.setObjectName("btn_primary")
        save_btn.setFixedHeight(36)
        save_btn.setFixedWidth(140)
        save_btn.clicked.connect(self._save)
        btn_row.addWidget(save_btn)
        layout.addLayout(btn_row)

        layout.addStretch()

        # Security notice
        notice = QLabel(
            "🔒  Sentinel is a read-only monitoring tool. "
            "It never deletes, modifies, or executes files."
        )
        notice.setStyleSheet(
            f"color: {COLORS['text_muted']}; font-size: 11px; "
            f"border-top: 1px solid {COLORS['border']}; padding-top: 12px;"
        )
        notice.setWordWrap(True)
        layout.addWidget(notice)

    def _load_from_config(self) -> None:
        self._vt_key_edit.setText(self._config.vt_api_key or "")
        self._rate_limit_spin.setValue(self._config.vt_rate_limit)
        self._watch_path_edit.setText(str(self._config.watch_path))
        self._db_path_lbl.setText(str(self._config.db_path))
        self._reports_lbl.setText(str(self._config.reports_dir))
        self._quarantine_lbl.setText(str(self._config.quarantine_dir))

    def _browse_path(self) -> None:
        path = QFileDialog.getExistingDirectory(
            self, "Select Watch Folder", str(self._config.watch_path)
        )
        if path:
            self._watch_path_edit.setText(path)

    def _save(self) -> None:
        new_key = self._vt_key_edit.text().strip()
        self._config.vt_api_key = new_key

        new_rate = self._rate_limit_spin.value()
        self._config.vt_rate_limit = new_rate

        new_path = self._watch_path_edit.text().strip()
        if new_path and new_path != str(self._config.watch_path):
            self._config.watch_path = Path(new_path)
            self.watch_path_changed.emit(new_path)

        # Persist to .env
        self._write_env()

        QMessageBox.information(self, "Settings Saved", "Settings have been saved.")
        log.info("Settings saved.")

    def _write_env(self) -> None:
        """Write key settings to the .env file."""
        env_path = Path(__file__).parent.parent.parent / ".env"
        lines = [
            f"SENTINEL_VT_API_KEY={self._config.vt_api_key}",
            f"SENTINEL_VT_RATE_LIMIT={self._config.vt_rate_limit}",
            f"SENTINEL_WATCH_PATH={self._config.watch_path}",
        ]
        try:
            env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        except Exception as exc:
            log.warning("Could not write .env: %s", exc)
