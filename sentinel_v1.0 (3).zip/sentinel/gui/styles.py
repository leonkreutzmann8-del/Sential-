"""
gui/styles.py
=============
Global dark-mode stylesheet for Sentinel.
Inspired by Windows Defender / modern security-tool aesthetics.

Colour palette
--------------
  Background layers:  #0A0E1A  (darkest), #0F1628, #141B2D, #1A2238
  Surface / cards:    #1E2A42
  Border:             #253550
  Accent blue:        #0078D7  (Defender blue)
  Accent cyan:        #00B4D8
  Text primary:       #E8EDF5
  Text secondary:     #8B9CB8
  Danger red:         #E53935
  Warning orange:     #FF6D00
  Success green:      #00C853
  Suspicious yellow:  #FFD600
"""

# Colours exposed for use in Python code
COLORS = {
    "bg_darkest":   "#0A0E1A",
    "bg_deep":      "#0F1628",
    "bg_main":      "#141B2D",
    "bg_card":      "#1A2238",
    "bg_surface":   "#1E2A42",
    "border":       "#253550",
    "border_light": "#2E3F60",
    "accent":       "#0078D7",
    "accent_hover": "#1A8FEB",
    "accent_cyan":  "#00B4D8",
    "text_primary": "#E8EDF5",
    "text_secondary": "#8B9CB8",
    "text_muted":   "#4A5980",
    "danger":       "#E53935",
    "danger_light": "#FF5252",
    "warning":      "#FF6D00",
    "suspicious":   "#FFD600",
    "success":      "#00C853",
    "unknown":      "#8B9CB8",
}

GLOBAL_STYLESHEET = f"""
/* ====================================================
   Sentinel Global Stylesheet
   ==================================================== */

/* ── Base ─────────────────────────────────────────── */
QWidget {{
    background-color: {COLORS['bg_main']};
    color: {COLORS['text_primary']};
    font-family: "Segoe UI", "SF Pro Display", "Helvetica Neue", sans-serif;
    font-size: 13px;
}}

QMainWindow {{
    background-color: {COLORS['bg_darkest']};
}}

/* ── Menu bar ─────────────────────────────────────── */
QMenuBar {{
    background-color: {COLORS['bg_deep']};
    color: {COLORS['text_primary']};
    border-bottom: 1px solid {COLORS['border']};
    padding: 2px;
}}
QMenuBar::item:selected {{
    background-color: {COLORS['bg_surface']};
    border-radius: 4px;
}}
QMenu {{
    background-color: {COLORS['bg_surface']};
    border: 1px solid {COLORS['border']};
    border-radius: 6px;
    padding: 4px;
}}
QMenu::item {{
    padding: 6px 24px;
    border-radius: 4px;
}}
QMenu::item:selected {{
    background-color: {COLORS['accent']};
    color: white;
}}

/* ── Toolbar ──────────────────────────────────────── */
QToolBar {{
    background-color: {COLORS['bg_deep']};
    border-bottom: 1px solid {COLORS['border']};
    spacing: 6px;
    padding: 4px 8px;
}}

/* ── Status bar ───────────────────────────────────── */
QStatusBar {{
    background-color: {COLORS['bg_deep']};
    color: {COLORS['text_secondary']};
    border-top: 1px solid {COLORS['border']};
    font-size: 11px;
}}

/* ── Scroll bars ──────────────────────────────────── */
QScrollBar:vertical {{
    background: {COLORS['bg_card']};
    width: 8px;
    border-radius: 4px;
}}
QScrollBar::handle:vertical {{
    background: {COLORS['border_light']};
    border-radius: 4px;
    min-height: 24px;
}}
QScrollBar::handle:vertical:hover {{
    background: {COLORS['accent']};
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0;
}}
QScrollBar:horizontal {{
    background: {COLORS['bg_card']};
    height: 8px;
    border-radius: 4px;
}}
QScrollBar::handle:horizontal {{
    background: {COLORS['border_light']};
    border-radius: 4px;
    min-width: 24px;
}}
QScrollBar::handle:horizontal:hover {{
    background: {COLORS['accent']};
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
    width: 0;
}}

/* ── Push buttons ─────────────────────────────────── */
QPushButton {{
    background-color: {COLORS['bg_surface']};
    color: {COLORS['text_primary']};
    border: 1px solid {COLORS['border']};
    border-radius: 6px;
    padding: 7px 18px;
    font-weight: 500;
}}
QPushButton:hover {{
    background-color: {COLORS['border_light']};
    border-color: {COLORS['accent']};
}}
QPushButton:pressed {{
    background-color: {COLORS['accent']};
    border-color: {COLORS['accent']};
}}
QPushButton#btn_primary {{
    background-color: {COLORS['accent']};
    border-color: {COLORS['accent']};
    color: white;
    font-weight: 600;
}}
QPushButton#btn_primary:hover {{
    background-color: {COLORS['accent_hover']};
}}
QPushButton#btn_danger {{
    background-color: {COLORS['danger']};
    border-color: {COLORS['danger']};
    color: white;
}}
QPushButton#btn_danger:hover {{
    background-color: {COLORS['danger_light']};
}}

/* ── Line edits / inputs ──────────────────────────── */
QLineEdit {{
    background-color: {COLORS['bg_card']};
    border: 1px solid {COLORS['border']};
    border-radius: 6px;
    padding: 6px 10px;
    color: {COLORS['text_primary']};
    selection-background-color: {COLORS['accent']};
}}
QLineEdit:focus {{
    border-color: {COLORS['accent']};
}}
QLineEdit::placeholder {{
    color: {COLORS['text_muted']};
}}

/* ── Tab widget ───────────────────────────────────── */
QTabWidget::pane {{
    border: 1px solid {COLORS['border']};
    border-top: none;
    background-color: {COLORS['bg_main']};
}}
QTabBar::tab {{
    background-color: {COLORS['bg_card']};
    color: {COLORS['text_secondary']};
    border: 1px solid {COLORS['border']};
    border-bottom: none;
    padding: 8px 20px;
    margin-right: 2px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    font-weight: 500;
}}
QTabBar::tab:selected {{
    background-color: {COLORS['bg_main']};
    color: {COLORS['text_primary']};
    border-bottom: 2px solid {COLORS['accent']};
}}
QTabBar::tab:hover:!selected {{
    background-color: {COLORS['bg_surface']};
    color: {COLORS['text_primary']};
}}

/* ── Table views ──────────────────────────────────── */
QTableWidget, QTableView {{
    background-color: {COLORS['bg_card']};
    gridline-color: {COLORS['border']};
    border: 1px solid {COLORS['border']};
    border-radius: 6px;
    selection-background-color: {COLORS['accent']};
    alternate-background-color: {COLORS['bg_surface']};
}}
QTableWidget::item, QTableView::item {{
    padding: 4px 8px;
    border: none;
}}
QTableWidget::item:selected, QTableView::item:selected {{
    background-color: {COLORS['accent']};
    color: white;
}}
QHeaderView::section {{
    background-color: {COLORS['bg_deep']};
    color: {COLORS['text_secondary']};
    border: none;
    border-bottom: 1px solid {COLORS['border']};
    border-right: 1px solid {COLORS['border']};
    padding: 6px 8px;
    font-weight: 600;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}}

/* ── Progress bars ────────────────────────────────── */
QProgressBar {{
    background-color: {COLORS['bg_card']};
    border: 1px solid {COLORS['border']};
    border-radius: 6px;
    text-align: center;
    color: {COLORS['text_primary']};
    font-size: 11px;
    height: 16px;
}}
QProgressBar::chunk {{
    background-color: {COLORS['accent']};
    border-radius: 5px;
}}
QProgressBar#pb_danger::chunk {{
    background-color: {COLORS['danger']};
}}
QProgressBar#pb_warning::chunk {{
    background-color: {COLORS['warning']};
}}
QProgressBar#pb_success::chunk {{
    background-color: {COLORS['success']};
}}

/* ── Splitters ────────────────────────────────────── */
QSplitter::handle {{
    background-color: {COLORS['border']};
}}
QSplitter::handle:horizontal {{
    width: 2px;
}}
QSplitter::handle:vertical {{
    height: 2px;
}}

/* ── Group boxes ──────────────────────────────────── */
QGroupBox {{
    border: 1px solid {COLORS['border']};
    border-radius: 8px;
    margin-top: 16px;
    padding-top: 8px;
    color: {COLORS['text_secondary']};
    font-weight: 600;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 12px;
    padding: 0 4px;
    color: {COLORS['accent_cyan']};
}}

/* ── Labels ───────────────────────────────────────── */
QLabel#lbl_section_title {{
    font-size: 16px;
    font-weight: 700;
    color: {COLORS['text_primary']};
}}
QLabel#lbl_stat_number {{
    font-size: 28px;
    font-weight: 700;
}}
QLabel#lbl_stat_label {{
    font-size: 11px;
    color: {COLORS['text_muted']};
    text-transform: uppercase;
    letter-spacing: 0.5px;
}}
QLabel#lbl_threat_malicious {{
    color: {COLORS['danger']};
    font-weight: 700;
}}
QLabel#lbl_threat_suspicious {{
    color: {COLORS['suspicious']};
    font-weight: 700;
}}
QLabel#lbl_threat_clean {{
    color: {COLORS['success']};
    font-weight: 700;
}}
QLabel#lbl_threat_unknown {{
    color: {COLORS['unknown']};
    font-weight: 700;
}}

/* ── Combo boxes ──────────────────────────────────── */
QComboBox {{
    background-color: {COLORS['bg_card']};
    border: 1px solid {COLORS['border']};
    border-radius: 6px;
    padding: 5px 10px;
    color: {COLORS['text_primary']};
}}
QComboBox:focus {{
    border-color: {COLORS['accent']};
}}
QComboBox QAbstractItemView {{
    background-color: {COLORS['bg_surface']};
    border: 1px solid {COLORS['border']};
    selection-background-color: {COLORS['accent']};
}}

/* ── Text edits ───────────────────────────────────── */
QTextEdit, QPlainTextEdit {{
    background-color: {COLORS['bg_card']};
    border: 1px solid {COLORS['border']};
    border-radius: 6px;
    color: {COLORS['text_primary']};
    padding: 8px;
    font-family: "Cascadia Code", "JetBrains Mono", "Consolas", monospace;
    font-size: 12px;
    selection-background-color: {COLORS['accent']};
}}

/* ── Check boxes ──────────────────────────────────── */
QCheckBox {{
    color: {COLORS['text_primary']};
    spacing: 8px;
}}
QCheckBox::indicator {{
    width: 16px;
    height: 16px;
    border: 1px solid {COLORS['border']};
    border-radius: 3px;
    background-color: {COLORS['bg_card']};
}}
QCheckBox::indicator:checked {{
    background-color: {COLORS['accent']};
    border-color: {COLORS['accent']};
}}

/* ── Tool tips ────────────────────────────────────── */
QToolTip {{
    background-color: {COLORS['bg_surface']};
    color: {COLORS['text_primary']};
    border: 1px solid {COLORS['border']};
    border-radius: 4px;
    padding: 4px 8px;
    font-size: 12px;
}}

/* ── Separator ────────────────────────────────────── */
QFrame[frameShape="4"],
QFrame[frameShape="5"] {{
    color: {COLORS['border']};
}}

/* ── Notification widget ──────────────────────────── */
QFrame#notification_frame {{
    background-color: {COLORS['bg_surface']};
    border-left: 4px solid {COLORS['accent']};
    border-radius: 6px;
}}
QFrame#notification_danger {{
    border-left-color: {COLORS['danger']};
}}
QFrame#notification_warning {{
    border-left-color: {COLORS['warning']};
}}
QFrame#notification_success {{
    border-left-color: {COLORS['success']};
}}
"""
