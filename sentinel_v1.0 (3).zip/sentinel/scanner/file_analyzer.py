"""
scanner/file_analyzer.py
========================
Local (offline) file analysis engine.

Responsibilities
----------------
- Compute SHA-256 and MD5 hashes
- Detect MIME type / file extension
- Calculate Shannon entropy
- Extract printable ASCII strings
- Detect suspicious patterns (PowerShell, encoded URLs, etc.)
- Run optional YARA rules

SECURITY NOTE
-------------
This module READS files in binary mode only.
It NEVER executes, modifies, or deletes any file.
"""

from __future__ import annotations

import hashlib
import logging
import math
import os
import re
import string
from pathlib import Path
from typing import Optional

from core.models import FileMetadata

log = logging.getLogger("sentinel.scanner.file_analyzer")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Minimum consecutive printable ASCII characters to qualify as a "string"
_MIN_STRING_LEN = 6

# Maximum number of strings to keep (to avoid RAM blowout on large binaries)
_MAX_STRINGS = 500

# Maximum bytes to read for analysis (64 MB safety cap)
_READ_CAP = 64 * 1024 * 1024

# Suspicious patterns to search for inside extracted strings
# Each tuple is (pattern_name, compiled_regex)
_SUSPICIOUS_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("powershell",          re.compile(r"powershell", re.IGNORECASE)),
    ("cmd.exe",             re.compile(r"cmd\.exe",   re.IGNORECASE)),
    ("base64_blob",         re.compile(r"[A-Za-z0-9+/]{40,}={0,2}")),
    ("encoded_url",         re.compile(r"https?://[A-Za-z0-9%._/~:?#\[\]@!$&'()*+,;=-]{20,}", re.IGNORECASE)),
    ("registry_run_key",    re.compile(r"CurrentVersion\\Run", re.IGNORECASE)),
    ("vbs_script",          re.compile(r"\.(vbs|vbe|wsf|wsh)\b", re.IGNORECASE)),
    ("wscript_cscript",     re.compile(r"(wscript|cscript)\.exe", re.IGNORECASE)),
    ("mshta",               re.compile(r"mshta(\.exe)?", re.IGNORECASE)),
    ("certutil_decode",     re.compile(r"certutil.*-decode", re.IGNORECASE)),
    ("bitsadmin_transfer",  re.compile(r"bitsadmin.*transfer", re.IGNORECASE)),
    ("net_user_add",        re.compile(r"net\s+user\s+/add", re.IGNORECASE)),
    ("invoke_expression",   re.compile(r"Invoke-Expression|IEX\b", re.IGNORECASE)),
    ("download_string",     re.compile(r"DownloadString|WebClient", re.IGNORECASE)),
    ("bypass_execution",    re.compile(r"ExecutionPolicy\s+Bypass", re.IGNORECASE)),
    ("hidden_window",       re.compile(r"-WindowStyle\s+Hidden", re.IGNORECASE)),
    ("scheduled_task",      re.compile(r"schtasks(\.exe)?", re.IGNORECASE)),
    ("create_service",      re.compile(r"sc\.exe\s+create", re.IGNORECASE)),
]


class FileAnalyzer:
    """
    Performs all local, offline analysis on a file.

    Parameters
    ----------
    yara_rules_dir:
        Optional path to a directory of YARA rule files.
        Pass ``None`` to disable YARA scanning.
    """

    def __init__(self, yara_rules_dir: Optional[Path] = None) -> None:
        self._yara_rules = self._load_yara_rules(yara_rules_dir)

    # ------------------------------------------------------------------ #
    #  Public API                                                          #
    # ------------------------------------------------------------------ #

    def analyze(self, path: Path) -> FileMetadata:
        """
        Perform full local analysis of *path* and return a :class:`FileMetadata`.

        Parameters
        ----------
        path:
            Absolute path to the file.  Must exist and be readable.

        Returns
        -------
        FileMetadata
            Populated with all locally-derivable information.

        Raises
        ------
        FileNotFoundError
            If the file does not exist at analysis time.
        PermissionError
            If the process lacks read access.
        """
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")

        log.debug("Analyzing: %s", path.name)

        meta = FileMetadata(path=path)
        meta.size_bytes = path.stat().st_size
        meta.extension = path.suffix.lower()

        # Read raw bytes (capped to avoid RAM exhaustion)
        raw = self._read_bytes(path)

        # Hashes
        meta.sha256, meta.md5 = self._compute_hashes(raw)

        # MIME type detection
        meta.mime_type = self._detect_mime(path, raw)

        # Entropy
        meta.entropy = self._shannon_entropy(raw)

        # Strings
        meta.strings = self._extract_strings(raw)

        # Suspicious pattern matching against extracted strings
        meta.suspicious_patterns = self._find_suspicious_patterns(meta.strings)

        # YARA
        if self._yara_rules:
            meta.yara_matches = self._run_yara(path)

        log.debug(
            "%s | sha256=%s… | size=%d | entropy=%.2f | patterns=%s",
            path.name,
            meta.sha256[:12],
            meta.size_bytes,
            meta.entropy,
            meta.suspicious_patterns,
        )

        return meta

    # ------------------------------------------------------------------ #
    #  Internal helpers                                                    #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _read_bytes(path: Path) -> bytes:
        """Read up to _READ_CAP bytes from path."""
        size = path.stat().st_size
        with open(path, "rb") as fh:
            if size > _READ_CAP:
                log.warning(
                    "File %s is %d bytes; only reading first %d bytes for analysis.",
                    path.name, size, _READ_CAP
                )
            return fh.read(_READ_CAP)

    @staticmethod
    def _compute_hashes(data: bytes) -> tuple[str, str]:
        """Return (sha256_hex, md5_hex) for *data*."""
        sha256 = hashlib.sha256(data).hexdigest()
        md5    = hashlib.md5(data).hexdigest()      # noqa: S324 (MD5 ok for file-ID)
        return sha256, md5

    @staticmethod
    def _detect_mime(path: Path, header: bytes) -> str:
        """
        Best-effort MIME detection.

        Uses python-magic when available, falls back to a small built-in
        magic-byte table so the app still works without libmagic installed.
        """
        try:
            import magic  # type: ignore
            return magic.from_buffer(header[:4096], mime=True)
        except (ImportError, Exception):
            pass

        # Fallback: coarse magic-byte lookup
        signatures: list[tuple[bytes, str]] = [
            (b"MZ",                          "application/x-dosexec"),
            (b"\x7fELF",                     "application/x-elf"),
            (b"PK\x03\x04",                  "application/zip"),
            (b"\x1f\x8b",                    "application/gzip"),
            (b"Rar!",                         "application/x-rar"),
            (b"\xfd7zXZ",                    "application/x-xz"),
            (b"%PDF",                         "application/pdf"),
            (b"\xff\xd8\xff",                "image/jpeg"),
            (b"\x89PNG",                     "image/png"),
            (b"GIF8",                         "image/gif"),
            (b"BM",                           "image/bmp"),
            (b"<!DOCTYPE html",              "text/html"),
            (b"<html",                        "text/html"),
            (b"<?xml",                        "text/xml"),
        ]
        h = header[:16]
        for magic_bytes, mime in signatures:
            if h.startswith(magic_bytes):
                return mime

        # Text detection heuristic
        printable = sum(1 for b in header[:512] if 0x20 <= b <= 0x7E or b in (9, 10, 13))
        if len(header) > 0 and printable / min(len(header), 512) > 0.9:
            return "text/plain"

        return "application/octet-stream"

    @staticmethod
    def _shannon_entropy(data: bytes) -> float:
        """
        Calculate Shannon entropy of *data*.

        Returns a value in [0.0, 8.0].  Values above ~7.2 suggest
        compression or encryption.
        """
        if not data:
            return 0.0

        # Build byte-frequency table
        freq = [0] * 256
        for byte in data:
            freq[byte] += 1

        length = len(data)
        entropy = 0.0
        for count in freq:
            if count:
                p = count / length
                entropy -= p * math.log2(p)

        return round(entropy, 4)

    @staticmethod
    def _extract_strings(data: bytes) -> list[str]:
        """
        Extract printable ASCII strings of at least _MIN_STRING_LEN chars.

        Mirrors the behaviour of the classic Unix ``strings`` utility.
        """
        printable = set(string.printable.encode())
        results: list[str] = []
        current: list[int] = []

        for byte in data:
            if byte in printable:
                current.append(byte)
            else:
                if len(current) >= _MIN_STRING_LEN:
                    results.append(bytes(current).decode("ascii", errors="replace"))
                    if len(results) >= _MAX_STRINGS:
                        break
                current.clear()

        # Flush last run
        if len(current) >= _MIN_STRING_LEN and len(results) < _MAX_STRINGS:
            results.append(bytes(current).decode("ascii", errors="replace"))

        return results

    @staticmethod
    def _find_suspicious_patterns(strings: list[str]) -> list[str]:
        """
        Check each extracted string against _SUSPICIOUS_PATTERNS.

        Returns a deduplicated list of matched pattern names.
        """
        matched: set[str] = set()
        combined = "\n".join(strings)

        for name, regex in _SUSPICIOUS_PATTERNS:
            if regex.search(combined):
                matched.add(name)

        return sorted(matched)

    @staticmethod
    def _load_yara_rules(rules_dir: Optional[Path]):
        """
        Attempt to compile all YARA rules in *rules_dir*.

        Returns a compiled yara.Rules object, or None if:
          - yara-python is not installed
          - No rule files are found
          - Compilation fails
        """
        if rules_dir is None:
            return None
        try:
            import yara  # type: ignore

            rule_files = list(rules_dir.glob("*.yar")) + list(rules_dir.glob("*.yrc"))
            if not rule_files:
                log.debug("No YARA rule files found in %s", rules_dir)
                return None

            filepaths = {f.stem: str(f) for f in rule_files}
            compiled = yara.compile(filepaths=filepaths)
            log.info("Loaded %d YARA rule file(s) from %s", len(rule_files), rules_dir)
            return compiled

        except ImportError:
            log.debug("yara-python not installed; YARA scanning disabled.")
        except Exception as exc:
            log.warning("Failed to compile YARA rules: %s", exc)
        return None

    def _run_yara(self, path: Path) -> list[str]:
        """Run compiled YARA rules against *path*.  Returns matched rule names."""
        if self._yara_rules is None:
            return []
        try:
            matches = self._yara_rules.match(str(path))
            return [m.rule for m in matches]
        except Exception as exc:
            log.warning("YARA scan failed for %s: %s", path.name, exc)
            return []
