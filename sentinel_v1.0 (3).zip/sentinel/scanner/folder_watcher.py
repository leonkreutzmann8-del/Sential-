"""
scanner/folder_watcher.py
=========================
Filesystem monitor that watches the Downloads folder and emits signals
whenever a new, complete file appears.

Uses the ``watchdog`` library for OS-native change notifications
(inotify on Linux, FSEvents on macOS, ReadDirectoryChangesW on Windows).

SECURITY NOTE
-------------
This module ONLY reads filesystem event metadata (paths, sizes).
It does not execute, modify, or delete any file.
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Callable, Optional

from watchdog.events import (
    FileCreatedEvent,
    FileMovedEvent,
    FileSystemEventHandler,
)
import sys
if sys.platform == 'win32':
    try:
        from watchdog.observers.winapi import WindowsApiObserver as Observer
    except ImportError:
        from watchdog.observers import Observer
else:
    from watchdog.observers import Observer

log = logging.getLogger("sentinel.scanner.folder_watcher")

# How long (seconds) to wait after a file appears before considering it
# "complete" (i.e. the browser / downloader has finished writing to it).
_STABILITY_DELAY: float = 2.0

# Temporary file extensions to ignore (browsers write these during download)
_TEMP_EXTENSIONS: frozenset[str] = frozenset(
    {
        ".crdownload",  # Chrome
        ".part",        # Firefox
        ".tmp",
        ".temp",
        ".download",    # Safari
        ".opdownload",  # Opera
        ".!ut",         # µTorrent
        ".bc!",         # BitComet
        ".downloading",
    }
)


class _DownloadEventHandler(FileSystemEventHandler):
    """
    Internal watchdog event handler.

    Calls *on_new_file* (provided by FolderWatcher) with the Path of each
    newly completed file.

    Parameters
    ----------
    on_new_file:
        Callable that receives a ``Path`` for each qualifying new file.
    ignored_extensions:
        Additional extensions to skip (from Config).
    """

    def __init__(
        self,
        on_new_file: Callable[[Path], None],
        ignored_extensions: frozenset[str],
    ) -> None:
        super().__init__()
        self._on_new_file = on_new_file
        self._ignored = _TEMP_EXTENSIONS | ignored_extensions

    # ------------------------------------------------------------------
    #  watchdog callbacks
    # ------------------------------------------------------------------

    def on_created(self, event: FileCreatedEvent) -> None:  # type: ignore[override]
        if not event.is_directory:
            self._handle(Path(event.src_path))

    def on_moved(self, event: FileMovedEvent) -> None:  # type: ignore[override]
        # Browsers often write to a .crdownload then rename to final name
        if not event.is_directory:
            self._handle(Path(event.dest_path))

    # ------------------------------------------------------------------
    #  Internal logic
    # ------------------------------------------------------------------

    def _handle(self, path: Path) -> None:
        """Filter and dispatch a candidate path."""

        # Ignore dotfiles and hidden files
        if path.name.startswith("."):
            log.debug("Skipping hidden file: %s", path.name)
            return

        # Ignore temporary download extensions
        if path.suffix.lower() in self._ignored:
            log.debug("Skipping temp file: %s", path.name)
            return

        # Wait for the file to stop growing (stabilisation)
        if not self._wait_for_stable(path):
            log.debug("File disappeared before stabilisation: %s", path.name)
            return

        log.info("New file detected: %s  (%d bytes)", path.name, path.stat().st_size)
        self._on_new_file(path)

    @staticmethod
    def _wait_for_stable(
        path: Path,
        check_interval: float = 0.5,
        stable_for: float = _STABILITY_DELAY,
    ) -> bool:
        """
        Poll until the file size is stable for *stable_for* seconds,
        or return False if the file disappears.

        This prevents scanning a partially-written file.
        """
        stable_seconds: float = 0.0
        last_size: Optional[int] = None

        while stable_seconds < stable_for:
            try:
                current_size = path.stat().st_size
            except (FileNotFoundError, PermissionError):
                return False  # file gone

            if current_size == last_size:
                stable_seconds += check_interval
            else:
                stable_seconds = 0.0
                last_size = current_size

            time.sleep(check_interval)

        return path.exists()


class FolderWatcher:
    """
    Monitors a directory for new files and calls *on_new_file* for each.

    Usage
    -----
    ::
        watcher = FolderWatcher(
            watch_path=Path.home() / "Downloads",
            on_new_file=my_callback,
            ignored_extensions=config.ignored_extensions,
        )
        watcher.start()
        ...
        watcher.stop()

    The *on_new_file* callback is invoked on a background thread managed by
    watchdog.  The caller must ensure thread safety.
    """

    def __init__(
        self,
        watch_path: Path,
        on_new_file: Callable[[Path], None],
        ignored_extensions: frozenset[str] = frozenset(),
    ) -> None:
        self._watch_path = watch_path
        self._on_new_file = on_new_file
        self._ignored = ignored_extensions
        self._observer: Optional[Observer] = None

    # ------------------------------------------------------------------ #
    #  Lifecycle                                                           #
    # ------------------------------------------------------------------ #

    def start(self) -> None:
        """Start watching the folder."""
        if not self._watch_path.exists():
            log.warning(
                "Watch path does not exist: %s — creating it.", self._watch_path
            )
            self._watch_path.mkdir(parents=True, exist_ok=True)

        handler = _DownloadEventHandler(
            on_new_file=self._on_new_file,
            ignored_extensions=self._ignored,
        )

        self._observer = Observer()
        self._observer.schedule(handler, str(self._watch_path), recursive=False)
        self._observer.start()

        log.info("FolderWatcher started on: %s", self._watch_path)

    def stop(self) -> None:
        """Stop the watchdog observer cleanly."""
        if self._observer and self._observer.is_alive():
            self._observer.stop()
            self._observer.join(timeout=5)
            log.info("FolderWatcher stopped.")

    @property
    def is_running(self) -> bool:
        return self._observer is not None and self._observer.is_alive()
