"""
scanner/scan_queue.py
=====================
Thread-safe scan queue with rate-limiting and deduplication.

Architecture
------------
- FolderWatcher → ScanQueue (background thread) → ScanWorker threads
- Qt signals propagate results back to the GUI thread safely

The queue prevents:
  - Duplicate scans of the same SHA-256 within a session
  - VT API abuse (rate limiter enforces ≤ N requests/minute)
  - Runaway memory use (bounded deque)
"""

from __future__ import annotations

import logging
import queue
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable, Optional

from PySide6.QtCore import QObject, Signal

from core.config import Config
from core.models import ScanResult, ScanStatus, ThreatLevel
from scanner.file_analyzer import FileAnalyzer
from vt_api.vt_client import VTClient
from database.db_manager import DatabaseManager

log = logging.getLogger("sentinel.scanner.scan_queue")

# Maximum items that can sit in the queue at once
_QUEUE_MAX = 200


@dataclass
class _ScanJob:
    """Internal job record."""
    path: Path
    queued_at: datetime = field(default_factory=datetime.utcnow)


class ScanQueueSignals(QObject):
    """
    Qt signals for inter-thread communication.

    All GUI updates must happen on the main thread.
    These signals are emitted from worker threads and Qt marshals them.
    """
    # Emitted when a new job is added to the queue
    job_queued = Signal(str)  # filename

    # Emitted during scan (status update)
    scan_started = Signal(str)   # filename

    # Emitted when scan is fully complete
    scan_complete = Signal(object)   # ScanResult

    # Emitted on error
    scan_error = Signal(str, str)    # filename, error_message

    # Emitted with scanning stats (queued, processing, done)
    stats_updated = Signal(int, int, int)


class ScanQueue:
    """
    Manages the lifecycle of scan jobs.

    Parameters
    ----------
    config : Config
        Application configuration.
    db : DatabaseManager
        Database manager for persisting results.
    signals : ScanQueueSignals
        Qt signals object for GUI callbacks.
    num_workers : int
        Number of parallel scan worker threads.
    """

    def __init__(
        self,
        config: Config,
        db: DatabaseManager,
        signals: ScanQueueSignals,
        num_workers: int = 2,
    ) -> None:
        self._config = config
        self._db = db
        self._signals = signals
        self._num_workers = num_workers

        # FIFO work queue
        self._queue: queue.Queue[_ScanJob] = queue.Queue(maxsize=_QUEUE_MAX)

        # Deduplication: SHA-256 hashes scanned in this session
        self._seen_hashes: set[str] = set()
        self._seen_lock = threading.Lock()

        # Statistics counters (thread-safe via lock)
        self._stats_lock = threading.Lock()
        self._stat_queued = 0
        self._stat_processing = 0
        self._stat_done = 0

        # Sub-components
        self._analyzer = FileAnalyzer(yara_rules_dir=config.yara_rules_dir)
        self._vt_client = VTClient(config) if config.vt_configured else None

        # Rate limiter shared across workers
        self._rate_limiter = _RateLimiter(
            max_calls=config.vt_rate_limit,
            period=60.0,
        )

        self._running = False
        self._workers: list[threading.Thread] = []

    # ------------------------------------------------------------------ #
    #  Public API                                                          #
    # ------------------------------------------------------------------ #

    def start(self) -> None:
        """Spawn worker threads."""
        self._running = True
        for i in range(self._num_workers):
            t = threading.Thread(
                target=self._worker_loop,
                name=f"ScanWorker-{i+1}",
                daemon=True,
            )
            t.start()
            self._workers.append(t)
        log.info("ScanQueue started with %d worker(s).", self._num_workers)

    def stop(self) -> None:
        """Gracefully stop workers."""
        self._running = False
        # Poison pills for each worker
        for _ in self._workers:
            try:
                self._queue.put_nowait(None)  # type: ignore[arg-type]
            except queue.Full:
                pass
        for t in self._workers:
            t.join(timeout=5)
        log.info("ScanQueue stopped.")

    def enqueue(self, path: Path) -> bool:
        """
        Add a file to the scan queue.

        Returns True if enqueued, False if duplicate or queue full.
        """
        try:
            job = _ScanJob(path=path)
            self._queue.put_nowait(job)
            with self._stats_lock:
                self._stat_queued += 1
            self._signals.job_queued.emit(path.name)
            self._emit_stats()
            log.debug("Enqueued: %s", path.name)
            return True
        except queue.Full:
            log.warning("Scan queue full — dropping: %s", path.name)
            return False

    def enqueue_bulk(self, paths: list[Path]) -> int:
        """Enqueue multiple paths; returns count actually enqueued."""
        count = 0
        for p in paths:
            if self.enqueue(p):
                count += 1
        return count

    @property
    def queue_size(self) -> int:
        return self._queue.qsize()

    # ------------------------------------------------------------------ #
    #  Worker                                                              #
    # ------------------------------------------------------------------ #

    def _worker_loop(self) -> None:
        """Main loop for each worker thread."""
        log.debug("%s started.", threading.current_thread().name)

        while self._running:
            try:
                job = self._queue.get(timeout=1.0)
            except queue.Empty:
                continue

            if job is None:  # Poison pill
                break

            self._process_job(job)
            self._queue.task_done()

        log.debug("%s exiting.", threading.current_thread().name)

    def _process_job(self, job: _ScanJob) -> None:
        """Execute a single scan job end-to-end."""
        path = job.path
        name = path.name

        with self._stats_lock:
            self._stat_processing += 1
        self._emit_stats()

        result = ScanResult(
            file_path=str(path),
            filename=name,
            status=ScanStatus.HASHING,
        )
        self._signals.scan_started.emit(name)

        try:
            # -------- Step 1: Local analysis --------
            result.status = ScanStatus.HASHING
            meta = self._analyzer.analyze(path)
            result.metadata = meta

            # -------- Step 2: Deduplication by hash --------
            with self._seen_lock:
                if meta.sha256 in self._seen_hashes:
                    log.debug("Duplicate hash — skipping VT for %s", name)
                    # Try to load cached VT result from DB
                    cached = self._db.get_scan_by_hash(meta.sha256)
                    if cached and cached.vt_report:
                        result.vt_report = cached.vt_report
                        result.threat_level = cached.threat_level
                        result.status = ScanStatus.COMPLETE
                        result.compute_risk_score()
                        self._finalise(result)
                        return
                    result.status = ScanStatus.SKIPPED
                    self._finalise(result)
                    return
                self._seen_hashes.add(meta.sha256)

            # -------- Step 3: VirusTotal --------
            if self._vt_client:
                self._rate_limiter.acquire()
                result.status = ScanStatus.VT_LOOKUP
                vt_report = self._vt_client.lookup_or_upload(meta, path)
                result.vt_report = vt_report
                result.threat_level = vt_report.threat_level

            # -------- Step 4: Risk score --------
            result.compute_risk_score()
            result.status = ScanStatus.COMPLETE

        except FileNotFoundError:
            result.status = ScanStatus.ERROR
            result.error_message = "File not found (removed before scan)"
            log.warning("File gone: %s", name)

        except PermissionError as exc:
            result.status = ScanStatus.ERROR
            result.error_message = f"Permission denied: {exc}"
            log.warning("Permission denied: %s", name)

        except Exception as exc:
            result.status = ScanStatus.ERROR
            result.error_message = str(exc)
            log.exception("Unexpected error scanning %s", name)
            self._signals.scan_error.emit(name, str(exc))

        finally:
            self._finalise(result)
            with self._stats_lock:
                self._stat_processing -= 1
                self._stat_done += 1
            self._emit_stats()

    def _finalise(self, result: ScanResult) -> None:
        """Persist to DB and emit completion signal."""
        try:
            self._db.save_scan(result)
        except Exception as exc:
            log.error("DB save failed for %s: %s", result.filename, exc)
        self._signals.scan_complete.emit(result)

    def _emit_stats(self) -> None:
        with self._stats_lock:
            self._signals.stats_updated.emit(
                self._stat_queued,
                self._stat_processing,
                self._stat_done,
            )


# ---------------------------------------------------------------------------
# Simple token-bucket rate limiter
# ---------------------------------------------------------------------------

class _RateLimiter:
    """
    Thread-safe rate limiter.

    Allows at most *max_calls* calls per *period* seconds.
    Callers block in :meth:`acquire` until a token is available.
    """

    def __init__(self, max_calls: int, period: float) -> None:
        self._max_calls = max_calls
        self._period = period
        self._lock = threading.Lock()
        self._timestamps: deque[float] = deque()

    def acquire(self) -> None:
        with self._lock:
            now = time.monotonic()
            # Remove timestamps older than the window
            while self._timestamps and self._timestamps[0] < now - self._period:
                self._timestamps.popleft()

            if len(self._timestamps) >= self._max_calls:
                # Sleep until the oldest timestamp leaves the window
                sleep_for = self._period - (now - self._timestamps[0])
                if sleep_for > 0:
                    log.debug(
                        "Rate limiter sleeping %.1fs (VT API quota)", sleep_for
                    )
                    time.sleep(sleep_for)
                    now = time.monotonic()
                    while self._timestamps and self._timestamps[0] < now - self._period:
                        self._timestamps.popleft()

            self._timestamps.append(time.monotonic())
