@echo off
:: ============================================================
::  Sentinel Security Monitor — Starter
::  Doppelklick zum Starten
:: ============================================================
title Sentinel Security Monitor
setlocal

set SCRIPT_DIR=%~dp0

:: Prüfe ob .venv existiert
if not exist "%SCRIPT_DIR%.venv\Scripts\python.exe" (
    echo.
    echo  FEHLER: Virtuelle Umgebung nicht gefunden!
    echo  Bitte zuerst install.bat ausführen.
    echo.
    pause
    exit /b 1
)

:: Prüfe ob .env existiert
if not exist "%SCRIPT_DIR%.env" (
    echo  HINWEIS: Keine .env Datei gefunden.
    echo  Kopiere .env.example zu .env ...
    copy "%SCRIPT_DIR%.env.example" "%SCRIPT_DIR%.env" >nul
    echo  Bitte .env mit deinem VirusTotal API Key befüllen!
    notepad "%SCRIPT_DIR%.env"
)

:: Starte Sentinel
cd /d "%SCRIPT_DIR%"
"%SCRIPT_DIR%.venv\Scripts\python.exe" main.py

:: Falls Fehler aufgetreten — Fenster offen halten
if %errorlevel% neq 0 (
    echo.
    echo  Sentinel wurde mit Fehlercode %errorlevel% beendet.
    echo  Bitte überprüfe die Fehlermeldung oben.
    pause
)

endlocal
