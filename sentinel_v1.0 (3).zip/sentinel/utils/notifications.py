"""
utils/notifications.py
======================
Desktop notification support for threat alerts.

Uses plyer for cross-platform OS notifications.
Falls back silently if plyer is not installed.
"""

from __future__ import annotations

import logging
from typing import Optional

from core.models import ScanResult, ThreatLevel

log = logging.getLogger("sentinel.utils.notifications")

_PLYER_AVAILABLE: Optional[bool] = None


def _check_plyer() -> bool:
    global _PLYER_AVAILABLE
    if _PLYER_AVAILABLE is None:
        try:
            import plyer  # type: ignore  # noqa: F401
            _PLYER_AVAILABLE = True
        except ImportError:
            _PLYER_AVAILABLE = False
            log.debug("plyer not installed; desktop notifications disabled.")
    return _PLYER_AVAILABLE


def notify_threat(result: ScanResult) -> None:
    """
    Send a desktop notification for a detected threat.

    Only fires for MALICIOUS or SUSPICIOUS files.
    Does nothing if plyer is not installed.
    """
    if result.threat_level not in (ThreatLevel.MALICIOUS, ThreatLevel.SUSPICIOUS):
        return
    if not _check_plyer():
        return

    try:
        from plyer import notification  # type: ignore

        vt = result.vt_report
        if vt and vt.total_engines > 0:
            message = vt.summary_label
        else:
            message = f"Suspicious patterns detected in {result.filename}"

        title = (
            "🚨 Threat Detected — Sentinel"
            if result.threat_level == ThreatLevel.MALICIOUS
            else "⚠️ Suspicious File — Sentinel"
        )

        notification.notify(
            title=title,
            message=f"{result.filename}\n{message}",
            app_name="Sentinel Security Monitor",
            timeout=8,
        )
        log.info("Desktop notification sent for: %s", result.filename)

    except Exception as exc:
        log.debug("Desktop notification failed: %s", exc)
