"""
utils/quarantine.py
===================
Safe quarantine manager.

Moves a suspicious file to the quarantine directory and records
the original path so it can be restored later.

SECURITY NOTES
--------------
- Files are MOVED (not copied), removing them from their original location.
- Files are renamed with a .quarantined extension to prevent accidental execution.
- Metadata is recorded in a JSON sidecar file for auditing.
- Sentinel NEVER automatically quarantines files — this is always a manual,
  user-initiated action.
"""

from __future__ import annotations

import json
import logging
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional

log = logging.getLogger("sentinel.utils.quarantine")


class QuarantineManager:
    """
    Manages the quarantine directory.

    Parameters
    ----------
    quarantine_dir : Path
        Directory where quarantined files are stored.
    """

    def __init__(self, quarantine_dir: Path) -> None:
        self._dir = quarantine_dir
        self._dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ #
    #  Public API                                                          #
    # ------------------------------------------------------------------ #

    def quarantine(self, file_path: Path, sha256: str = "", reason: str = "") -> Path:
        """
        Move *file_path* to quarantine.

        The file is renamed to ``<sha256_prefix>_<original_name>.quarantined``
        to prevent accidental execution.

        Parameters
        ----------
        file_path : Path
            Source file to quarantine.
        sha256 : str
            SHA-256 of the file (for naming and metadata).
        reason : str
            Human-readable reason for quarantine.

        Returns
        -------
        Path
            Location of the quarantined file.

        Raises
        ------
        FileNotFoundError
            If *file_path* does not exist.
        PermissionError
            If the file cannot be moved.
        """
        if not file_path.exists():
            raise FileNotFoundError(f"Cannot quarantine: {file_path} not found")

        prefix = sha256[:16] if sha256 else "unknown"
        dest_name = f"{prefix}_{file_path.name}.quarantined"
        dest = self._dir / dest_name

        # Avoid name collision
        counter = 1
        while dest.exists():
            dest_name = f"{prefix}_{file_path.name}_{counter}.quarantined"
            dest = self._dir / dest_name
            counter += 1

        shutil.move(str(file_path), str(dest))
        log.warning(
            "Quarantined: %s → %s  (reason: %s)",
            file_path.name, dest.name, reason or "manual"
        )

        # Write sidecar metadata
        meta = {
            "original_path":  str(file_path),
            "quarantined_at": datetime.utcnow().isoformat(),
            "sha256":         sha256,
            "reason":         reason,
            "quarantine_path": str(dest),
        }
        sidecar = dest.with_suffix(".json")
        sidecar.write_text(json.dumps(meta, indent=2), encoding="utf-8")

        return dest

    def restore(self, quarantined_path: Path) -> Path:
        """
        Restore a quarantined file to its original location.

        Parameters
        ----------
        quarantined_path : Path
            Path of the .quarantined file inside the quarantine directory.

        Returns
        -------
        Path
            The restored original path.
        """
        sidecar = quarantined_path.with_suffix(".json")
        if not sidecar.exists():
            raise FileNotFoundError(f"Sidecar metadata not found for {quarantined_path.name}")

        meta = json.loads(sidecar.read_text(encoding="utf-8"))
        original = Path(meta["original_path"])

        if original.exists():
            raise FileExistsError(
                f"Cannot restore: a file already exists at {original}"
            )

        shutil.move(str(quarantined_path), str(original))
        sidecar.unlink(missing_ok=True)
        log.info("Restored: %s → %s", quarantined_path.name, original)
        return original

    def list_quarantined(self) -> list[dict]:
        """Return metadata for all quarantined files."""
        items = []
        for json_file in sorted(self._dir.glob("*.json")):
            try:
                meta = json.loads(json_file.read_text(encoding="utf-8"))
                # Check if the quarantined file still exists
                qpath = Path(meta.get("quarantine_path", ""))
                meta["exists"] = qpath.exists()
                items.append(meta)
            except (json.JSONDecodeError, OSError):
                pass
        return items

    def delete_permanently(self, quarantined_path: Path) -> None:
        """
        Permanently delete a quarantined file and its sidecar.

        This action is irreversible.
        """
        sidecar = quarantined_path.with_suffix(".json")
        if quarantined_path.exists():
            quarantined_path.unlink()
        if sidecar.exists():
            sidecar.unlink()
        log.info("Permanently deleted quarantined file: %s", quarantined_path.name)
