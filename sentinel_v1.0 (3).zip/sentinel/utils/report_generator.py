"""
utils/report_generator.py
==========================
Generates a PDF scan report from a list of ScanResults.

Uses ReportLab (reportlab>=4.0) — install via pip.
Falls back gracefully with a warning if not available.
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from core.models import ScanResult, ThreatLevel

log = logging.getLogger("sentinel.utils.report_generator")


def generate_pdf_report(results: list[ScanResult], output_path: Path) -> Path:
    """
    Generate a PDF report at *output_path* from *results*.

    Parameters
    ----------
    results : list[ScanResult]
        Scan results to include.
    output_path : Path
        Destination PDF file.

    Returns
    -------
    Path
        The path to the generated PDF.

    Raises
    ------
    ImportError
        If reportlab is not installed.
    """
    try:
        from reportlab.lib import colors as rl_colors
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import cm
        from reportlab.platypus import (
            SimpleDocTemplate,
            Table,
            TableStyle,
            Paragraph,
            Spacer,
            HRFlowable,
        )
        from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
    except ImportError as exc:
        raise ImportError(
            "reportlab is required for PDF export. "
            "Install it with: pip install reportlab"
        ) from exc

    # ------------------------------------------------------------------ #
    #  Styles                                                              #
    # ------------------------------------------------------------------ #
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        "SentinelTitle",
        parent=styles["Title"],
        fontSize=20,
        textColor=rl_colors.HexColor("#E8EDF5"),
        spaceAfter=4,
    )
    sub_style = ParagraphStyle(
        "SentinelSub",
        parent=styles["Normal"],
        fontSize=10,
        textColor=rl_colors.HexColor("#8B9CB8"),
        spaceAfter=16,
    )
    section_style = ParagraphStyle(
        "SentinelSection",
        parent=styles["Heading2"],
        fontSize=12,
        textColor=rl_colors.HexColor("#00B4D8"),
        spaceBefore=12,
        spaceAfter=6,
    )
    body_style = ParagraphStyle(
        "SentinelBody",
        parent=styles["Normal"],
        fontSize=9,
        textColor=rl_colors.HexColor("#E8EDF5"),
    )

    # ------------------------------------------------------------------ #
    #  Document                                                            #
    # ------------------------------------------------------------------ #
    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        leftMargin=2 * cm,
        rightMargin=2 * cm,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
        title="Sentinel Scan Report",
        author="Sentinel Security Monitor",
    )

    story = []

    # ── Title block ──
    story.append(Paragraph("🛡 Sentinel Security Monitor", title_style))
    story.append(Paragraph(
        f"Scan Report  |  Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}  "
        f"|  Total Scans: {len(results)}",
        sub_style,
    ))
    story.append(HRFlowable(width="100%", thickness=1, color=rl_colors.HexColor("#253550")))
    story.append(Spacer(1, 0.4 * cm))

    # ── Summary stats ──
    total = len(results)
    malicious  = sum(1 for r in results if r.threat_level == ThreatLevel.MALICIOUS)
    suspicious = sum(1 for r in results if r.threat_level == ThreatLevel.SUSPICIOUS)
    clean      = sum(1 for r in results if r.threat_level == ThreatLevel.CLEAN)

    story.append(Paragraph("Summary", section_style))

    summary_data = [
        ["Total Scans", "Clean", "Suspicious", "Malicious"],
        [str(total), str(clean), str(suspicious), str(malicious)],
    ]
    summary_table = Table(summary_data, colWidths=[4 * cm] * 4)
    summary_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), rl_colors.HexColor("#1E2A42")),
        ("TEXTCOLOR",  (0, 0), (-1, 0), rl_colors.HexColor("#8B9CB8")),
        ("TEXTCOLOR",  (0, 1), (-1, 1), rl_colors.HexColor("#E8EDF5")),
        ("FONTSIZE",   (0, 0), (-1, -1), 10),
        ("FONTNAME",   (0, 1), (-1, 1), "Helvetica-Bold"),
        ("FONTSIZE",   (0, 1), (-1, 1), 16),
        ("ALIGN",      (0, 0), (-1, -1), "CENTER"),
        ("VALIGN",     (0, 0), (-1, -1), "MIDDLE"),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [
            rl_colors.HexColor("#1E2A42"), rl_colors.HexColor("#141B2D")
        ]),
        ("GRID", (0, 0), (-1, -1), 0.5, rl_colors.HexColor("#253550")),
        ("TOPPADDING",    (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(summary_table)
    story.append(Spacer(1, 0.4 * cm))

    # ── Scan results table ──
    story.append(Paragraph("Scan Results", section_style))

    headers = ["Filename", "Threat", "Risk", "Detections", "SHA-256 (partial)", "Scanned At"]
    table_data = [headers]

    _tl_label = {
        ThreatLevel.MALICIOUS:  "MALICIOUS",
        ThreatLevel.SUSPICIOUS: "SUSPICIOUS",
        ThreatLevel.CLEAN:      "CLEAN",
        ThreatLevel.UNKNOWN:    "UNKNOWN",
    }
    _tl_color = {
        ThreatLevel.MALICIOUS:  rl_colors.HexColor("#E53935"),
        ThreatLevel.SUSPICIOUS: rl_colors.HexColor("#FFD600"),
        ThreatLevel.CLEAN:      rl_colors.HexColor("#00C853"),
        ThreatLevel.UNKNOWN:    rl_colors.HexColor("#8B9CB8"),
    }

    for r in results:
        vt = r.vt_report
        meta = r.metadata
        det = (
            f"{vt.malicious + vt.suspicious}/{vt.total_engines}"
            if vt and vt.total_engines > 0 else "—"
        )
        sha = meta.sha256[:20] + "…" if meta and meta.sha256 else "—"
        ts  = r.scanned_at.strftime("%Y-%m-%d %H:%M") if r.scanned_at else "—"
        table_data.append([
            r.filename[:40],
            _tl_label.get(r.threat_level, "UNKNOWN"),
            str(r.risk_score),
            det,
            sha,
            ts,
        ])

    col_widths = [5 * cm, 2.2 * cm, 1.5 * cm, 2.5 * cm, 3.5 * cm, 3.3 * cm]
    results_table = Table(table_data, colWidths=col_widths, repeatRows=1)

    ts_style = [
        ("BACKGROUND",    (0, 0), (-1, 0),  rl_colors.HexColor("#0F1628")),
        ("TEXTCOLOR",     (0, 0), (-1, 0),  rl_colors.HexColor("#8B9CB8")),
        ("FONTNAME",      (0, 0), (-1, 0),  "Helvetica-Bold"),
        ("FONTSIZE",      (0, 0), (-1, -1), 8),
        ("ALIGN",         (2, 1), (3, -1),  "CENTER"),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING",    (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [
            rl_colors.HexColor("#141B2D"), rl_colors.HexColor("#1A2238")
        ]),
        ("GRID", (0, 0), (-1, -1), 0.3, rl_colors.HexColor("#253550")),
        ("TEXTCOLOR", (0, 1), (-1, -1), rl_colors.HexColor("#E8EDF5")),
    ]

    # Colour the threat column per row
    for i, r in enumerate(results, start=1):
        c = _tl_color.get(r.threat_level, rl_colors.HexColor("#8B9CB8"))
        ts_style.append(("TEXTCOLOR", (1, i), (1, i), c))

    results_table.setStyle(TableStyle(ts_style))
    story.append(results_table)
    story.append(Spacer(1, 0.6 * cm))

    # ── Footer ──
    story.append(HRFlowable(width="100%", thickness=0.5, color=rl_colors.HexColor("#253550")))
    story.append(Spacer(1, 0.2 * cm))
    story.append(Paragraph(
        "This report was generated by Sentinel Security Monitor. "
        "Sentinel is a defensive, educational tool — it never deletes, modifies, or executes files.",
        ParagraphStyle("footer", parent=body_style, fontSize=8,
                       textColor=rl_colors.HexColor("#4A5980")),
    ))

    doc.build(story)
    log.info("PDF report saved to %s", output_path)
    return output_path
