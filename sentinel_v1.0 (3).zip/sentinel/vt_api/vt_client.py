"""
vt_api/vt_client.py
====================
VirusTotal v3 API client.

Workflow
--------
1. Hash lookup  (GET /files/{sha256})
   → If known: parse and return
2. If unknown: Upload file  (POST /files)
   → Returns analysis ID
3. Poll analysis  (GET /analyses/{id})  until complete
4. Fetch full report  (GET /files/{sha256})

Rate limiting is handled by the caller (ScanQueue._rate_limiter).

SECURITY NOTE
-------------
- Files are ONLY uploaded if the hash is unknown to VT
- No automatic deletion / blocking
- API key is passed in the HTTP header only — never logged
"""

from __future__ import annotations

import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import requests
from requests.adapters import HTTPAdapter, Retry

from core.config import Config
from core.models import EngineResult, FileMetadata, VTReport

log = logging.getLogger("sentinel.vt_api.vt_client")

_VT_BASE = "https://www.virustotal.com/api/v3"
_TIMEOUT = 30  # seconds


class VTClientError(Exception):
    """Raised when the VT API returns an unexpected response."""


class VTClient:
    """
    Thin wrapper around the VirusTotal v3 REST API.

    Parameters
    ----------
    config : Config
        Application configuration.  Must have a valid ``vt_api_key``.
    """

    def __init__(self, config: Config) -> None:
        self._api_key = config.vt_api_key
        self._poll_interval = config.vt_poll_interval
        self._poll_max = config.vt_poll_max_attempts
        self._max_upload = config.max_upload_size

        # Requests session with retries on transient errors
        self._session = requests.Session()
        self._session.headers.update({"x-apikey": self._api_key})

        retry = Retry(
            total=3,
            backoff_factor=1.5,
            status_forcelist={429, 500, 502, 503, 504},
            allowed_methods={"GET", "POST"},
        )
        adapter = HTTPAdapter(max_retries=retry)
        self._session.mount("https://", adapter)

    # ------------------------------------------------------------------ #
    #  Public API                                                          #
    # ------------------------------------------------------------------ #

    def lookup_or_upload(self, meta: FileMetadata, path: Path) -> VTReport:
        """
        Main entry point.

        1. Try hash lookup.
        2. If not found AND file is within size limit → upload and poll.
        3. Return parsed VTReport.
        """
        log.info("VT lookup: %s (sha256=%s…)", meta.filename, meta.sha256[:12])

        # --- Step 1: hash lookup ---
        report = self._lookup_hash(meta.sha256)
        if report is not None:
            log.info(
                "VT cache hit: %s → %s",
                meta.filename,
                report.summary_label,
            )
            return report

        # --- Step 2: upload ---
        if meta.size_bytes > self._max_upload:
            log.warning(
                "File %s is too large to upload (%d bytes > %d limit). "
                "Returning empty VT report.",
                meta.filename,
                meta.size_bytes,
                self._max_upload,
            )
            return VTReport(sha256=meta.sha256)

        log.info("VT upload: %s (%d bytes)", meta.filename, meta.size_bytes)
        analysis_id = self._upload_file(path)
        if not analysis_id:
            return VTReport(sha256=meta.sha256)

        # --- Step 3: poll ---
        self._poll_analysis(analysis_id)

        # --- Step 4: fetch final report ---
        report = self._lookup_hash(meta.sha256)
        if report is None:
            log.warning("VT report still unavailable after polling: %s", meta.filename)
            report = VTReport(sha256=meta.sha256, analysis_id=analysis_id)

        report.uploaded = True
        report.first_submission = True
        return report

    # ------------------------------------------------------------------ #
    #  Internal helpers                                                    #
    # ------------------------------------------------------------------ #

    def _lookup_hash(self, sha256: str) -> Optional[VTReport]:
        """
        GET /files/{sha256}

        Returns None when the file is unknown to VirusTotal (404).
        Raises VTClientError on unexpected HTTP errors.
        """
        url = f"{_VT_BASE}/files/{sha256}"
        try:
            resp = self._session.get(url, timeout=_TIMEOUT)
        except requests.RequestException as exc:
            raise VTClientError(f"Network error during hash lookup: {exc}") from exc

        if resp.status_code == 404:
            return None
        if resp.status_code == 401:
            raise VTClientError("Invalid VirusTotal API key.")
        if resp.status_code == 429:
            raise VTClientError("VirusTotal API rate limit exceeded.")
        if not resp.ok:
            raise VTClientError(
                f"VT hash lookup failed: HTTP {resp.status_code}"
            )

        return self._parse_file_report(resp.json())

    def _upload_file(self, path: Path) -> Optional[str]:
        """
        POST /files

        Returns the analysis ID (str) on success, None on failure.
        """
        url = f"{_VT_BASE}/files"
        try:
            with open(path, "rb") as fh:
                resp = self._session.post(
                    url,
                    files={"file": (path.name, fh, "application/octet-stream")},
                    timeout=120,  # Large files need more time
                )
        except (requests.RequestException, OSError) as exc:
            log.error("VT upload failed: %s", exc)
            return None

        if resp.status_code == 429:
            log.warning("VT rate limit hit during upload.")
            return None
        if not resp.ok:
            log.error("VT upload error: HTTP %d — %s", resp.status_code, resp.text[:200])
            return None

        data = resp.json()
        analysis_id = data.get("data", {}).get("id")
        log.debug("VT upload successful; analysis_id=%s", analysis_id)
        return analysis_id

    def _poll_analysis(self, analysis_id: str) -> None:
        """
        GET /analyses/{id}  — poll until status is "completed".

        Respects _poll_interval and _poll_max_attempts limits.
        """
        url = f"{_VT_BASE}/analyses/{analysis_id}"

        for attempt in range(1, self._poll_max + 1):
            try:
                resp = self._session.get(url, timeout=_TIMEOUT)
            except requests.RequestException as exc:
                log.warning("VT poll error (attempt %d): %s", attempt, exc)
                time.sleep(self._poll_interval)
                continue

            if not resp.ok:
                log.warning("VT poll HTTP %d (attempt %d)", resp.status_code, attempt)
                time.sleep(self._poll_interval)
                continue

            data = resp.json()
            status = (
                data.get("data", {})
                    .get("attributes", {})
                    .get("status", "")
            )
            log.debug("VT analysis status (attempt %d): %s", attempt, status)

            if status == "completed":
                return

            time.sleep(self._poll_interval)

        log.warning(
            "VT analysis %s did not complete after %d attempts.",
            analysis_id, self._poll_max
        )

    # ------------------------------------------------------------------ #
    #  Response parsing                                                    #
    # ------------------------------------------------------------------ #

    def _parse_file_report(self, data: dict[str, Any]) -> VTReport:
        """
        Parse a /files/{sha256} response into a VTReport.

        The VT v3 response structure:
        {
          "data": {
            "attributes": {
              "last_analysis_stats": {...},
              "last_analysis_results": {
                "<engine>": {"category": "...", "result": "..."},
                ...
              },
              "reputation": int,
              "meaningful_name": "...",
              "sha256": "...",
              "last_analysis_date": int (unix timestamp)
            }
          }
        }
        """
        attrs: dict = data.get("data", {}).get("attributes", {})

        report = VTReport()
        report.sha256 = attrs.get("sha256", "")
        report.meaningful_name = attrs.get("meaningful_name", "")
        report.reputation = attrs.get("reputation", 0)

        # Detection stats
        stats: dict = attrs.get("last_analysis_stats", {})
        report.malicious  = stats.get("malicious",  0)
        report.suspicious = stats.get("suspicious", 0)
        report.undetected = stats.get("undetected", 0)
        report.harmless   = stats.get("harmless",   0)
        report.timeout    = stats.get("timeout",    0)

        # Last analysis date
        ts = attrs.get("last_analysis_date")
        if ts:
            try:
                report.last_analysis_date = datetime.utcfromtimestamp(ts)
            except (ValueError, OSError, OverflowError):
                pass

        # Per-engine results
        results: dict = attrs.get("last_analysis_results", {})
        for engine_name, engine_data in results.items():
            report.engine_results.append(
                EngineResult(
                    engine_name=engine_name,
                    category=engine_data.get("category", "undetected"),
                    result=engine_data.get("result"),
                    engine_version=engine_data.get("engine_version", ""),
                    update=engine_data.get("engine_update", ""),
                )
            )

        # Sort: malicious first, then suspicious, then undetected
        _order = {"malicious": 0, "suspicious": 1, "undetected": 2}
        report.engine_results.sort(
            key=lambda e: (_order.get(e.category, 3), e.engine_name.lower())
        )

        return report
